# MCP Server Pack — 10 Production-Ready MCP Servers

> 🎁 **Get the full pack on Gumroad → [link goes here at launch]**

Ten focused, single-purpose MCP servers for Claude Code, Cursor, Cline,
Windsurf — drop them into any MCP client config and your agent gains
ten new tools. All zero-cloud, all stdio, all MIT-licensed.

| Server | Tools | What it does |
|---|---|---|
| `calc-mcp` | `eval`, `convert` | Math expressions + unit conversion |
| `time-mcp` | `now`, `parse`, `format`, `diff`, `ago`, `tz` | Date/time/timezone utilities |
| `fs-search-mcp` | `grep`, `find`, `tree` | File search + listing in a directory |
| `hn-search-mcp` | `search`, `top`, `item` | HackerNews API wrapper |
| `arxiv-mcp` | `search`, `abstract` | arXiv paper search + abstract fetch |
| `regex-mcp` | `match`, `replace`, `explain` | Regex testing + explanation |
| `json-tools-mcp` | `validate`, `infer-schema`, `query` | JSON validation + jq-like query |
| `markdown-tools-mcp` | `toc`, `frontmatter`, `links` | Markdown TOC + frontmatter + link extract |
| `wikipedia-mcp` | `search`, `summary` | Wikipedia search + summary fetch |
| `dns-tools-mcp` | `lookup`, `reverse`, `mx`, `txt` | DNS lookup + record types |

## Free public sample

The repo includes ONE complete server (`calc-mcp`) under MIT for free
inspection. The other nine + the master install scripts + the unified
config snippets ship in the [Gumroad bundle](https://gumroad.com/l/mcp-server-pack).

## Quick start (free sample)

```bash
git clone https://github.com/LuuOW/mcp-server-pack
cd mcp-server-pack/servers/calc
npm install
node index.mjs   # waits for MCP JSON-RPC on stdin
```

## Drop into Claude Code

```json
{
  "mcpServers": {
    "calc": {
      "command": "node",
      "args":    ["/abs/path/to/mcp-server-pack/servers/calc/index.mjs"]
    }
  }
}
```

## Get the full pack

```
🎁  10 servers · install scripts · unified Claude Code config
🎁  $49 on Gumroad — MIT license, commercial-use OK, no resale of bundle
```

[Buy the pack →](https://gumroad.com/l/mcp-server-pack)

---

By [@LuuOW](https://github.com/LuuOW) · Same author as
[meridian-skills-mcp](https://github.com/LuuOW/meridian-mcp) and
[build-your-own-mcp](https://github.com/LuuOW/build-your-own-mcp).
