#!/usr/bin/env node
// wikipedia-mcp — Wikipedia search + summary via the public REST API. Zero deps.
import readline from 'node:readline'

const REST = 'https://en.wikipedia.org/api/rest_v1'
const ACTION = 'https://en.wikipedia.org/w/api.php'

const TOOLS = [
  { name: 'search',  description: 'Search Wikipedia. Returns top page hits with title + snippet.', inputSchema: { type: 'object', properties: { query: { type: 'string' }, limit: { type: 'number' } }, required: ['query'] } },
  { name: 'summary', description: 'Fetch the summary (first paragraph + thumbnail) for a Wikipedia page title.', inputSchema: { type: 'object', properties: { title: { type: 'string' } }, required: ['title'] } },
]

async function search({ query, limit = 10 }) {
  const url = `${ACTION}?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=${Math.min(limit, 20)}&format=json&origin=*`
  const r = await fetch(url, { headers: { 'user-agent': 'wikipedia-mcp/0.1 (https://github.com/LuuOW/mcp-server-pack)' } })
  if (!r.ok) throw new Error(`wikipedia ${r.status}`)
  const data = await r.json()
  return {
    query,
    results: (data.query?.search || []).map(s => ({
      title: s.title,
      snippet: s.snippet.replace(/<[^>]+>/g, ''),
      pageid: s.pageid,
      url: `https://en.wikipedia.org/wiki/${encodeURIComponent(s.title.replace(/ /g, '_'))}`,
    })),
  }
}

async function summary({ title }) {
  const r = await fetch(`${REST}/page/summary/${encodeURIComponent(title.replace(/ /g, '_'))}`, {
    headers: { 'user-agent': 'wikipedia-mcp/0.1 (https://github.com/LuuOW/mcp-server-pack)' },
  })
  if (!r.ok) throw new Error(`wikipedia ${r.status} for "${title}"`)
  const data = await r.json()
  return {
    title:       data.title,
    extract:     data.extract,
    description: data.description,
    thumbnail:   data.thumbnail?.source,
    url:         data.content_urls?.desktop?.page,
    type:        data.type,
  }
}

const handlers = { search, summary }
const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', async (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'wikipedia-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = await handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
