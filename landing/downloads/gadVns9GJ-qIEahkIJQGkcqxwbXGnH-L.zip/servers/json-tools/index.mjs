#!/usr/bin/env node
// json-tools-mcp — validate, infer schema, jq-lite query. Zero deps.
import readline from 'node:readline'

const TOOLS = [
  { name: 'validate',     description: 'Parse + validate a JSON string. Returns parsed value or detailed error.', inputSchema: { type: 'object', properties: { input: { type: 'string' } }, required: ['input'] } },
  { name: 'infer-schema', description: 'Infer a JSON Schema (draft-07) from a sample JSON value.',                inputSchema: { type: 'object', properties: { input: { type: 'string' } }, required: ['input'] } },
  { name: 'query',        description: 'jq-lite path query. Supports .a.b, .a[0], .a[]?, .a|.b. Returns matched values.', inputSchema: { type: 'object', properties: { input: { type: 'string' }, path: { type: 'string' } }, required: ['input', 'path'] } },
]

function infer(value) {
  if (value === null) return { type: 'null' }
  if (Array.isArray(value)) {
    if (!value.length) return { type: 'array', items: {} }
    return { type: 'array', items: infer(value[0]) }
  }
  const t = typeof value
  if (t === 'object') {
    const props = {}
    const required = []
    for (const k of Object.keys(value)) {
      props[k] = infer(value[k])
      required.push(k)
    }
    return { type: 'object', properties: props, required }
  }
  if (t === 'number')  return Number.isInteger(value) ? { type: 'integer' } : { type: 'number' }
  if (t === 'boolean') return { type: 'boolean' }
  if (t === 'string')  return { type: 'string' }
  return {}
}

// jq-lite: dot path with optional [N], [], .a|.b alternation
function query(value, path) {
  // Split top-level on | (alternation)
  const segs = path.split('|').map(s => s.trim()).filter(Boolean)
  let current = [value]
  for (const seg of segs) {
    const next = []
    for (const v of current) {
      const result = applyPath(v, seg)
      next.push(...result)
    }
    current = next
  }
  return current
}

function applyPath(v, p) {
  if (p === '.' || p === '') return [v]
  // Tokenize: .key  .key[N]  .key[]  [N]  []
  const tokens = []
  const re = /\.([a-zA-Z_][a-zA-Z0-9_]*)|\[(\d+)\]|\[\]/g
  let m
  while ((m = re.exec(p))) {
    if (m[1] !== undefined)      tokens.push({ kind: 'key', v: m[1] })
    else if (m[2] !== undefined) tokens.push({ kind: 'idx', v: parseInt(m[2], 10) })
    else                         tokens.push({ kind: 'all' })
  }
  let cur = [v]
  for (const t of tokens) {
    const next = []
    for (const x of cur) {
      if (x === undefined || x === null) continue
      if (t.kind === 'key' && typeof x === 'object' && !Array.isArray(x)) next.push(x[t.v])
      else if (t.kind === 'idx' && Array.isArray(x)) next.push(x[t.v])
      else if (t.kind === 'all' && Array.isArray(x)) next.push(...x)
    }
    cur = next.filter(x => x !== undefined)
  }
  return cur
}

const handlers = {
  validate: ({ input }) => {
    try { return { ok: true, value: JSON.parse(input) } }
    catch (e) { return { ok: false, error: e.message } }
  },
  'infer-schema': ({ input }) => ({ schema: infer(JSON.parse(input)) }),
  query: ({ input, path }) => ({ matches: query(JSON.parse(input), path) }),
}

const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'json-tools-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
