#!/usr/bin/env node
// time-mcp — date/time/timezone utilities. Zero deps.
import readline from 'node:readline'

const TOOLS = [
  { name: 'now',    description: 'Current ISO timestamp + Unix seconds + named timezone offset.', inputSchema: { type: 'object', properties: {} } },
  { name: 'parse',  description: 'Parse a string into ISO 8601. Accepts most common formats.',    inputSchema: { type: 'object', properties: { input: { type: 'string' } }, required: ['input'] } },
  { name: 'format', description: 'Format an ISO timestamp using a fmt string (YYYY/MM/DD/HH/mm/ss).', inputSchema: { type: 'object', properties: { input: { type: 'string' }, fmt: { type: 'string' } }, required: ['input', 'fmt'] } },
  { name: 'diff',   description: 'Difference between two ISO timestamps in {ms,s,m,h,d}.',         inputSchema: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' } }, required: ['from', 'to'] } },
  { name: 'ago',    description: 'Human-readable "X minutes ago" for an ISO timestamp.',           inputSchema: { type: 'object', properties: { input: { type: 'string' } }, required: ['input'] } },
  { name: 'tz',     description: 'Convert an ISO timestamp to a different IANA timezone string.',  inputSchema: { type: 'object', properties: { input: { type: 'string' }, tz: { type: 'string' } }, required: ['input', 'tz'] } },
]

function nowResult() {
  const d = new Date()
  return { iso: d.toISOString(), unix_ms: d.getTime(), unix_s: Math.floor(d.getTime()/1000), local: d.toString() }
}
function parseInput(s) {
  const d = new Date(s)
  if (isNaN(d.getTime())) throw new Error(`could not parse: ${s}`)
  return d
}
function format(d, fmt) {
  const pad = n => String(n).padStart(2, '0')
  return fmt
    .replace(/YYYY/g, d.getUTCFullYear())
    .replace(/MM/g, pad(d.getUTCMonth() + 1))
    .replace(/DD/g, pad(d.getUTCDate()))
    .replace(/HH/g, pad(d.getUTCHours()))
    .replace(/mm/g, pad(d.getUTCMinutes()))
    .replace(/ss/g, pad(d.getUTCSeconds()))
}
function diffOf(a, b) {
  const ms = b.getTime() - a.getTime()
  return { ms, s: ms / 1000, m: ms / 60000, h: ms / 3600000, d: ms / 86400000 }
}
function ago(d) {
  const ms = Date.now() - d.getTime()
  const sign = ms >= 0 ? 'ago' : 'from now'
  const abs = Math.abs(ms)
  if (abs < 60000)        return `${Math.round(abs/1000)}s ${sign}`
  if (abs < 3600000)      return `${Math.round(abs/60000)}m ${sign}`
  if (abs < 86400000)     return `${Math.round(abs/3600000)}h ${sign}`
  return `${Math.round(abs/86400000)}d ${sign}`
}

const handlers = {
  now:    () => nowResult(),
  parse:  ({ input }) => ({ iso: parseInput(input).toISOString() }),
  format: ({ input, fmt }) => ({ formatted: format(parseInput(input), fmt) }),
  diff:   ({ from, to }) => diffOf(parseInput(from), parseInput(to)),
  ago:    ({ input }) => ({ ago: ago(parseInput(input)) }),
  tz:     ({ input, tz }) => {
    const d = parseInput(input)
    return { converted: d.toLocaleString('en-CA', { timeZone: tz, hour12: false }), tz }
  },
}

const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'time-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
