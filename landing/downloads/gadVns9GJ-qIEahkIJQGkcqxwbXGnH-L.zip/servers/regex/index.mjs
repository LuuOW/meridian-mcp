#!/usr/bin/env node
// regex-mcp — regex match/replace/explain. Zero deps.
import readline from 'node:readline'

const TOOLS = [
  { name: 'match',   description: 'Test a regex against a string. Returns all matches with groups.', inputSchema: { type: 'object', properties: { pattern: { type: 'string' }, input: { type: 'string' }, flags: { type: 'string', description: 'JS regex flags, default "g"' } }, required: ['pattern', 'input'] } },
  { name: 'replace', description: 'Apply a regex replacement.',                                       inputSchema: { type: 'object', properties: { pattern: { type: 'string' }, input: { type: 'string' }, replacement: { type: 'string' }, flags: { type: 'string' } }, required: ['pattern', 'input', 'replacement'] } },
  { name: 'explain', description: 'Break a regex into its tokens with plain-English notes.',          inputSchema: { type: 'object', properties: { pattern: { type: 'string' } }, required: ['pattern'] } },
]

function safeFlags(f) {
  // Only allow standard JS regex flags
  return (f || 'g').split('').filter(c => 'gimsuyd'.includes(c)).join('')
}

function match({ pattern, input, flags }) {
  const re = new RegExp(pattern, safeFlags(flags))
  const matches = []
  if (re.global) {
    let m
    while ((m = re.exec(input)) && matches.length < 1000) {
      matches.push({ match: m[0], index: m.index, groups: m.slice(1) })
      if (m.index === re.lastIndex) re.lastIndex++  // empty match guard
    }
  } else {
    const m = re.exec(input)
    if (m) matches.push({ match: m[0], index: m.index, groups: m.slice(1) })
  }
  return { count: matches.length, matches }
}

function replace({ pattern, input, replacement, flags }) {
  const re = new RegExp(pattern, safeFlags(flags))
  return { result: input.replace(re, replacement) }
}

function explain({ pattern }) {
  const tokens = []
  let i = 0
  while (i < pattern.length) {
    const c = pattern[i]
    if (c === '\\' && i + 1 < pattern.length) {
      const next = pattern[i+1]
      const meaning = ({
        d: 'any digit (0-9)', D: 'any non-digit', w: 'word character (alphanumeric + _)',
        W: 'non-word character', s: 'whitespace', S: 'non-whitespace',
        b: 'word boundary', B: 'non-word boundary', n: 'newline', t: 'tab', r: 'carriage return',
      })[next] || `literal "${next}"`
      tokens.push({ token: c + next, meaning })
      i += 2; continue
    }
    if (c === '.') { tokens.push({ token: '.',     meaning: 'any char (except newline)' }); i++; continue }
    if (c === '^') { tokens.push({ token: '^',     meaning: 'start of input/line' }); i++; continue }
    if (c === '$') { tokens.push({ token: '$',     meaning: 'end of input/line' }); i++; continue }
    if (c === '*') { tokens.push({ token: '*',     meaning: '0 or more of previous' }); i++; continue }
    if (c === '+') { tokens.push({ token: '+',     meaning: '1 or more of previous' }); i++; continue }
    if (c === '?') { tokens.push({ token: '?',     meaning: '0 or 1 of previous (or non-greedy)' }); i++; continue }
    if (c === '(') {
      const isNonCapture = pattern.slice(i, i+3) === '(?:'
      tokens.push({ token: isNonCapture ? '(?:' : '(', meaning: isNonCapture ? 'non-capturing group' : 'capturing group' })
      i += isNonCapture ? 3 : 1; continue
    }
    if (c === ')') { tokens.push({ token: ')', meaning: 'end group' }); i++; continue }
    if (c === '[') {
      const end = pattern.indexOf(']', i)
      const cls = pattern.slice(i, end + 1)
      tokens.push({ token: cls, meaning: `character class — match any of: ${cls.slice(1, -1)}` })
      i = end + 1; continue
    }
    if (c === '{') {
      const end = pattern.indexOf('}', i)
      const q = pattern.slice(i, end + 1)
      tokens.push({ token: q, meaning: `quantifier ${q}` })
      i = end + 1; continue
    }
    if (c === '|') { tokens.push({ token: '|', meaning: 'alternation (or)' }); i++; continue }
    tokens.push({ token: c, meaning: `literal "${c}"` })
    i++
  }
  return { pattern, tokens }
}

const handlers = { match, replace, explain }
const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'regex-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
