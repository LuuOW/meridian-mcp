#!/usr/bin/env node
// arxiv-mcp — arXiv search + abstract fetch via the public Atom API. Zero deps.
import readline from 'node:readline'

const ARXIV = 'http://export.arxiv.org/api/query'

const TOOLS = [
  { name: 'search',   description: 'Search arXiv for papers matching a query string (e.g. "qnlp", "cat:cs.LG title:transformers"). Returns top hits with title, authors, summary, link.', inputSchema: { type: 'object', properties: { query: { type: 'string' }, max: { type: 'number' } }, required: ['query'] } },
  { name: 'abstract', description: 'Fetch the abstract for a specific arXiv ID (e.g. "2403.01234").', inputSchema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
]

// Lightweight Atom XML parser — just what we need from arXiv responses.
function parseEntries(xml) {
  const entries = []
  const entryRe = /<entry>([\s\S]*?)<\/entry>/g
  let m
  while ((m = entryRe.exec(xml))) {
    const e = m[1]
    const get = re => { const x = e.match(re); return x ? x[1].replace(/\s+/g, ' ').trim() : null }
    const authors = []
    const aRe = /<author>\s*<name>([^<]+)<\/name>\s*<\/author>/g
    let a; while ((a = aRe.exec(e))) authors.push(a[1].trim())
    entries.push({
      id:       get(/<id>([^<]+)<\/id>/),
      title:    get(/<title>([\s\S]*?)<\/title>/),
      summary:  get(/<summary>([\s\S]*?)<\/summary>/),
      authors,
      published: get(/<published>([^<]+)<\/published>/),
      updated:  get(/<updated>([^<]+)<\/updated>/),
      link:     (e.match(/<link\s+rel="alternate"[^>]*href="([^"]+)"/) || [])[1],
      pdf:      (e.match(/<link\s+title="pdf"[^>]*href="([^"]+)"/) || [])[1],
    })
  }
  return entries
}

async function search({ query, max = 10 }) {
  const url = `${ARXIV}?search_query=${encodeURIComponent(query)}&start=0&max_results=${Math.min(max, 30)}`
  const r = await fetch(url)
  if (!r.ok) throw new Error(`arXiv ${r.status}`)
  return { query, results: parseEntries(await r.text()) }
}

async function abstract({ id }) {
  const url = `${ARXIV}?id_list=${encodeURIComponent(id)}`
  const r = await fetch(url)
  if (!r.ok) throw new Error(`arXiv ${r.status}`)
  const entries = parseEntries(await r.text())
  if (!entries.length) throw new Error(`arXiv ID not found: ${id}`)
  return entries[0]
}

const handlers = { search, abstract }
const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', async (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'arxiv-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = await handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
