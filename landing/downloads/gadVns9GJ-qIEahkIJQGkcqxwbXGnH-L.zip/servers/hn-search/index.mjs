#!/usr/bin/env node
// hn-search-mcp — HackerNews API wrapper. Zero deps.
import readline from 'node:readline'

const ALGOLIA = 'https://hn.algolia.com/api/v1'
const FIREBASE = 'https://hacker-news.firebaseio.com/v0'

const TOOLS = [
  { name: 'search', description: 'Search HackerNews via Algolia API. Returns top hits with title, URL, author, score, date.', inputSchema: { type: 'object', properties: { query: { type: 'string' }, hits: { type: 'number', description: 'max results, default 10' } }, required: ['query'] } },
  { name: 'top',    description: 'Get the top N stories from HN front page (default 10).', inputSchema: { type: 'object', properties: { limit: { type: 'number' } } } },
  { name: 'item',   description: 'Fetch a specific HN item by ID (story, comment, etc.).', inputSchema: { type: 'object', properties: { id: { type: 'number' } }, required: ['id'] } },
]

async function search({ query, hits = 10 }) {
  const r = await fetch(`${ALGOLIA}/search?query=${encodeURIComponent(query)}&hitsPerPage=${Math.min(hits, 30)}`)
  if (!r.ok) throw new Error(`HN Algolia ${r.status}`)
  const data = await r.json()
  return {
    query,
    results: data.hits.map(h => ({
      title:    h.title || h.story_title,
      url:      h.url || `https://news.ycombinator.com/item?id=${h.objectID}`,
      author:   h.author,
      points:   h.points,
      comments: h.num_comments,
      created:  h.created_at,
      objectID: h.objectID,
    })),
  }
}

async function top({ limit = 10 }) {
  const ids = await (await fetch(`${FIREBASE}/topstories.json`)).json()
  const slice = ids.slice(0, Math.min(limit, 30))
  const items = await Promise.all(slice.map(id => fetch(`${FIREBASE}/item/${id}.json`).then(r => r.json())))
  return { stories: items.map(i => ({ id: i.id, title: i.title, url: i.url, by: i.by, score: i.score, time: i.time })) }
}

async function item({ id }) {
  const r = await fetch(`${FIREBASE}/item/${id}.json`)
  if (!r.ok) throw new Error(`HN ${r.status}`)
  return await r.json()
}

const handlers = { search, top, item }
const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', async (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'hn-search-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = await handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
