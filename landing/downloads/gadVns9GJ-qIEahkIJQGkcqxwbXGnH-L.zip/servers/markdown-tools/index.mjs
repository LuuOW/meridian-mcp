#!/usr/bin/env node
// markdown-tools-mcp — TOC, frontmatter, link extraction. Zero deps.
import readline from 'node:readline'

const TOOLS = [
  { name: 'toc',         description: 'Generate a Markdown table-of-contents from heading lines (h1-h6).', inputSchema: { type: 'object', properties: { input: { type: 'string' }, max_level: { type: 'number' } }, required: ['input'] } },
  { name: 'frontmatter', description: 'Extract YAML frontmatter from a Markdown document. Returns body separately.', inputSchema: { type: 'object', properties: { input: { type: 'string' } }, required: ['input'] } },
  { name: 'links',       description: 'Extract all [text](url) Markdown links from a document.',           inputSchema: { type: 'object', properties: { input: { type: 'string' } }, required: ['input'] } },
]

function slugify(s) {
  return s.toLowerCase().replace(/[^a-z0-9 ]/g, '').trim().replace(/\s+/g, '-')
}

function toc({ input, max_level = 6 }) {
  const lines = []
  for (const line of input.split('\n')) {
    const m = line.match(/^(#{1,6})\s+(.+?)\s*$/)
    if (!m) continue
    const level = m[1].length
    if (level > max_level) continue
    const title = m[2]
    const indent = '  '.repeat(level - 1)
    lines.push(`${indent}- [${title}](#${slugify(title)})`)
  }
  return { toc: lines.join('\n'), count: lines.length }
}

function frontmatter({ input }) {
  if (!input.startsWith('---')) return { frontmatter: null, body: input }
  const end = input.indexOf('\n---', 3)
  if (end === -1) return { frontmatter: null, body: input }
  const yamlText = input.slice(3, end).trim()
  const body = input.slice(end + 4).replace(/^\n/, '')
  // Tiny YAML — only key: value pairs (no nesting)
  const fm = {}
  for (const line of yamlText.split('\n')) {
    const m = line.match(/^([a-zA-Z0-9_-]+)\s*:\s*(.*)$/)
    if (!m) continue
    let v = m[2].trim()
    if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1)
    if (v === 'true')  v = true
    else if (v === 'false') v = false
    else if (/^-?\d+$/.test(v)) v = parseInt(v, 10)
    fm[m[1]] = v
  }
  return { frontmatter: fm, body }
}

function links({ input }) {
  const out = []
  const re = /\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g
  let m
  while ((m = re.exec(input))) out.push({ text: m[1], url: m[2] })
  return { links: out, count: out.length }
}

const handlers = { toc, frontmatter, links }
const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'markdown-tools-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
