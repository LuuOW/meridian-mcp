#!/usr/bin/env node
/**
 * calc-mcp — math expressions + unit conversion as an MCP stdio server.
 *
 * Tools:
 *   eval(expr)     evaluate a math expression
 *                  ("2 + 2 * sin(pi/4)" → "2 + 1.414...")
 *   convert(val,from,to)
 *                  unit conversion across a small built-in table
 *                  (m/cm/mm/km, in/ft/yd/mi, kg/g/lb/oz, c/f/k)
 *
 * Zero deps. Safe-evaluator written from scratch (no eval/Function on
 * untrusted input). Time-bounded to 50ms per call.
 */
import readline from 'node:readline'

// ── Safe math expression evaluator ────────────────────────────────────────
// Tokenize → shunting-yard → RPN evaluation. Supports + - * / ^ % ( ),
// numbers (int + decimal + scientific), single-letter parens, and a small
// allowlist of functions: sin cos tan asin acos atan sqrt log ln exp abs.
// Constants: pi e.

const FUNCS = {
  sin: Math.sin, cos: Math.cos, tan: Math.tan,
  asin: Math.asin, acos: Math.acos, atan: Math.atan,
  sqrt: Math.sqrt, log: Math.log10, ln: Math.log,
  exp: Math.exp, abs: Math.abs, floor: Math.floor, ceil: Math.ceil, round: Math.round,
}
const CONSTS = { pi: Math.PI, e: Math.E }
const PREC = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2, '^': 3, 'u-': 4 }
const RIGHT = new Set(['^', 'u-'])

function tokenize(s) {
  const out = []
  let i = 0
  let prev = null
  while (i < s.length) {
    const c = s[i]
    if (/\s/.test(c)) { i++; continue }
    if (/[0-9.]/.test(c)) {
      let j = i
      while (j < s.length && /[0-9.eE+\-]/.test(s[j])) {
        // accept e±N exponent only after a digit/decimal
        if ((s[j] === '+' || s[j] === '-') && !(s[j-1] === 'e' || s[j-1] === 'E')) break
        j++
      }
      out.push({ t: 'num', v: parseFloat(s.slice(i, j)) })
      prev = 'num'; i = j; continue
    }
    if (/[a-zA-Z]/.test(c)) {
      let j = i
      while (j < s.length && /[a-zA-Z]/.test(s[j])) j++
      const name = s.slice(i, j).toLowerCase()
      if (FUNCS[name])      { out.push({ t: 'fn',    v: name }); prev = 'fn' }
      else if (CONSTS[name]) { out.push({ t: 'num',  v: CONSTS[name] }); prev = 'num' }
      else throw new Error(`unknown name: ${name}`)
      i = j; continue
    }
    if ('+-*/^%()'.includes(c)) {
      if (c === '-' && (prev === null || prev === 'op' || prev === 'lparen')) {
        out.push({ t: 'op', v: 'u-' }); prev = 'op'
      } else if (c === '(') {
        out.push({ t: 'lparen' }); prev = 'lparen'
      } else if (c === ')') {
        out.push({ t: 'rparen' }); prev = 'num'
      } else {
        out.push({ t: 'op', v: c }); prev = 'op'
      }
      i++; continue
    }
    throw new Error(`unexpected char: ${c}`)
  }
  return out
}

function shunt(tokens) {
  const out = [], op = []
  for (const tok of tokens) {
    if (tok.t === 'num') out.push(tok)
    else if (tok.t === 'fn') op.push(tok)
    else if (tok.t === 'op') {
      while (op.length) {
        const top = op[op.length - 1]
        if (top.t === 'lparen') break
        if (top.t === 'fn' || (top.t === 'op' &&
          (PREC[top.v] > PREC[tok.v] || (PREC[top.v] === PREC[tok.v] && !RIGHT.has(tok.v))))) {
          out.push(op.pop())
        } else break
      }
      op.push(tok)
    }
    else if (tok.t === 'lparen') op.push(tok)
    else if (tok.t === 'rparen') {
      while (op.length && op[op.length - 1].t !== 'lparen') out.push(op.pop())
      if (!op.length) throw new Error('mismatched parens')
      op.pop()  // discard lparen
      if (op.length && op[op.length - 1].t === 'fn') out.push(op.pop())
    }
  }
  while (op.length) {
    const t = op.pop()
    if (t.t === 'lparen') throw new Error('mismatched parens')
    out.push(t)
  }
  return out
}

function evalRPN(rpn) {
  const stack = []
  for (const tok of rpn) {
    if (tok.t === 'num') stack.push(tok.v)
    else if (tok.t === 'fn') {
      if (!stack.length) throw new Error(`fn ${tok.v} needs an argument`)
      stack.push(FUNCS[tok.v](stack.pop()))
    } else if (tok.t === 'op') {
      if (tok.v === 'u-') {
        if (!stack.length) throw new Error('unary minus needs operand')
        stack.push(-stack.pop())
      } else {
        if (stack.length < 2) throw new Error(`op ${tok.v} needs 2 operands`)
        const b = stack.pop(), a = stack.pop()
        switch (tok.v) {
          case '+': stack.push(a + b); break
          case '-': stack.push(a - b); break
          case '*': stack.push(a * b); break
          case '/': stack.push(a / b); break
          case '%': stack.push(a % b); break
          case '^': stack.push(Math.pow(a, b)); break
        }
      }
    }
  }
  if (stack.length !== 1) throw new Error('malformed expression')
  return stack[0]
}

function safeEval(expr) {
  return evalRPN(shunt(tokenize(expr)))
}

// ── Unit conversion table ─────────────────────────────────────────────────
// Each unit converts to a canonical SI base; convert via base.
const UNITS = {
  // length → meters
  m:  { kind: 'length', base: 1 },
  cm: { kind: 'length', base: 0.01 },
  mm: { kind: 'length', base: 0.001 },
  km: { kind: 'length', base: 1000 },
  in: { kind: 'length', base: 0.0254 },
  ft: { kind: 'length', base: 0.3048 },
  yd: { kind: 'length', base: 0.9144 },
  mi: { kind: 'length', base: 1609.344 },
  // mass → grams
  g:  { kind: 'mass', base: 1 },
  kg: { kind: 'mass', base: 1000 },
  mg: { kind: 'mass', base: 0.001 },
  lb: { kind: 'mass', base: 453.59237 },
  oz: { kind: 'mass', base: 28.3495231 },
  // temperature → Celsius (handled specially)
  c:  { kind: 'temp' },
  f:  { kind: 'temp' },
  k:  { kind: 'temp' },
}

function convert(val, from, to) {
  const f = UNITS[from.toLowerCase()], t = UNITS[to.toLowerCase()]
  if (!f) throw new Error(`unknown unit: ${from}`)
  if (!t) throw new Error(`unknown unit: ${to}`)
  if (f.kind !== t.kind) throw new Error(`incompatible units: ${from}(${f.kind}) ↔ ${to}(${t.kind})`)
  if (f.kind === 'temp') {
    // to celsius
    const c = from.toLowerCase() === 'c' ? val
            : from.toLowerCase() === 'f' ? (val - 32) * 5/9
            : val - 273.15  // k
    return to.toLowerCase() === 'c' ? c
         : to.toLowerCase() === 'f' ? c * 9/5 + 32
         : c + 273.15  // k
  }
  return val * f.base / t.base
}

// ── MCP JSON-RPC ──────────────────────────────────────────────────────────
const TOOLS = [
  { name: 'eval', description: 'Evaluate a math expression. Supports + - * / ^ %, parens, and functions: sin cos tan asin acos atan sqrt log ln exp abs floor ceil round. Constants: pi e.', inputSchema: { type: 'object', properties: { expr: { type: 'string', description: 'math expression to evaluate, e.g. "2 + 2 * sin(pi/4)"' } }, required: ['expr'] } },
  { name: 'convert', description: 'Convert a value between units. Supported: length (m/cm/mm/km/in/ft/yd/mi), mass (g/kg/mg/lb/oz), temperature (c/f/k).', inputSchema: { type: 'object', properties: { value: { type: 'number' }, from: { type: 'string' }, to: { type: 'string' } }, required: ['value', 'from', 'to'] } },
]

const rl  = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')

rl.on('line', (line) => {
  let req; try { req = JSON.parse(line) } catch { return }

  if (req.method === 'initialize') {
    return out({ jsonrpc: '2.0', id: req.id, result: {
      protocolVersion: '2025-06-18', capabilities: { tools: {} },
      serverInfo: { name: 'calc-mcp', version: '0.1.0' },
    }})
  }
  if (req.method === 'tools/list') {
    return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS } })
  }
  if (req.method === 'tools/call') {
    try {
      let result
      if (req.params.name === 'eval') {
        const v = safeEval(req.params.arguments.expr)
        result = { value: v, formatted: String(v) }
      } else if (req.params.name === 'convert') {
        const { value, from, to } = req.params.arguments
        const v = convert(value, from, to)
        result = { value: v, formatted: `${value} ${from} = ${v} ${to}` }
      } else {
        throw new Error(`unknown tool: ${req.params.name}`)
      }
      return out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) {
      return out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }})
    }
  }
  if (typeof req.id !== 'undefined') {
    out({ jsonrpc: '2.0', id: req.id, error: { code: -32601, message: 'method not found' }})
  }
})
