#!/usr/bin/env node
// fs-search-mcp — file search + listing in a directory. Zero deps.
import readline from 'node:readline'
import { promises as fs } from 'node:fs'
import path from 'node:path'

const ROOT = process.env.FS_SEARCH_ROOT || process.cwd()
const MAX_FILES   = parseInt(process.env.FS_SEARCH_MAX_FILES   || '5000', 10)
const MAX_MATCHES = parseInt(process.env.FS_SEARCH_MAX_MATCHES || '500', 10)
const IGNORED = new Set(['.git', 'node_modules', 'dist', 'build', '.next', '__pycache__', '.venv'])

async function* walk(dir, maxDepth = 8, depth = 0) {
  if (depth > maxDepth) return
  let entries
  try { entries = await fs.readdir(dir, { withFileTypes: true }) } catch { return }
  for (const e of entries) {
    if (IGNORED.has(e.name)) continue
    const p = path.join(dir, e.name)
    if (e.isDirectory()) yield* walk(p, maxDepth, depth + 1)
    else if (e.isFile())   yield p
  }
}

const TOOLS = [
  { name: 'grep', description: 'Search for a regex/literal pattern across text files in the configured root.', inputSchema: { type: 'object', properties: { pattern: { type: 'string' }, glob: { type: 'string', description: 'optional path substring filter' }, regex: { type: 'boolean', description: 'treat pattern as regex (default: false, literal)' } }, required: ['pattern'] } },
  { name: 'find', description: 'List files matching a glob-substring filter (e.g. ".ts" or "test").',           inputSchema: { type: 'object', properties: { glob: { type: 'string' } }, required: ['glob'] } },
  { name: 'tree', description: 'Print a directory tree from the root, capped at maxDepth.',                     inputSchema: { type: 'object', properties: { maxDepth: { type: 'number' } } } },
]

async function grep({ pattern, glob, regex }) {
  const re = regex ? new RegExp(pattern) : new RegExp(pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
  const matches = []
  let scanned = 0
  for await (const file of walk(ROOT)) {
    if (++scanned > MAX_FILES) break
    if (glob && !file.includes(glob)) continue
    let text
    try { text = await fs.readFile(file, 'utf8') } catch { continue }
    const lines = text.split('\n')
    for (let i = 0; i < lines.length; i++) {
      if (re.test(lines[i])) {
        matches.push({ file: path.relative(ROOT, file), line: i + 1, text: lines[i].slice(0, 200) })
        if (matches.length >= MAX_MATCHES) return { matches, truncated: true, scanned }
      }
    }
  }
  return { matches, truncated: false, scanned }
}

async function find({ glob }) {
  const out = []
  for await (const file of walk(ROOT)) {
    if (file.includes(glob)) out.push(path.relative(ROOT, file))
    if (out.length >= MAX_MATCHES) break
  }
  return { matches: out, count: out.length }
}

async function tree({ maxDepth = 3 }) {
  const lines = []
  async function walkTree(dir, depth, prefix) {
    if (depth > maxDepth) return
    const entries = (await fs.readdir(dir, { withFileTypes: true })).filter(e => !IGNORED.has(e.name)).sort((a, b) => a.name.localeCompare(b.name))
    for (let i = 0; i < entries.length; i++) {
      const e = entries[i]
      const isLast = i === entries.length - 1
      lines.push(prefix + (isLast ? '└── ' : '├── ') + e.name + (e.isDirectory() ? '/' : ''))
      if (e.isDirectory()) await walkTree(path.join(dir, e.name), depth + 1, prefix + (isLast ? '    ' : '│   '))
    }
  }
  await walkTree(ROOT, 1, '')
  return { tree: lines.join('\n'), root: ROOT }
}

const handlers = { grep, find, tree }
const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', async (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'fs-search-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = await handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
