#!/usr/bin/env node
// dns-tools-mcp — DNS lookup, reverse, MX, TXT records via Node's built-in resolver.
import readline from 'node:readline'
import dns from 'node:dns/promises'

const TOOLS = [
  { name: 'lookup',  description: 'A/AAAA lookup for a hostname.',         inputSchema: { type: 'object', properties: { host: { type: 'string' } }, required: ['host'] } },
  { name: 'reverse', description: 'Reverse DNS lookup (PTR) for an IP address.', inputSchema: { type: 'object', properties: { ip:   { type: 'string' } }, required: ['ip'] } },
  { name: 'mx',      description: 'MX records for a domain.',              inputSchema: { type: 'object', properties: { domain: { type: 'string' } }, required: ['domain'] } },
  { name: 'txt',     description: 'TXT records for a domain (SPF, verifications, etc.).', inputSchema: { type: 'object', properties: { domain: { type: 'string' } }, required: ['domain'] } },
  { name: 'all',     description: 'Resolve a hostname for all common record types (A, AAAA, MX, TXT, NS, CNAME).', inputSchema: { type: 'object', properties: { domain: { type: 'string' } }, required: ['domain'] } },
]

async function lookup({ host }) {
  const v4 = await dns.resolve4(host).catch(() => [])
  const v6 = await dns.resolve6(host).catch(() => [])
  return { host, a: v4, aaaa: v6 }
}

async function reverse({ ip }) {
  const names = await dns.reverse(ip)
  return { ip, names }
}

async function mx({ domain }) {
  const records = await dns.resolveMx(domain)
  return { domain, mx: records.sort((a, b) => a.priority - b.priority) }
}

async function txt({ domain }) {
  const records = await dns.resolveTxt(domain)
  return { domain, txt: records.map(r => r.join('')) }
}

async function all({ domain }) {
  const r = {}
  await Promise.all([
    dns.resolve4(domain).then(x => r.a = x).catch(() => r.a = []),
    dns.resolve6(domain).then(x => r.aaaa = x).catch(() => r.aaaa = []),
    dns.resolveMx(domain).then(x => r.mx = x.sort((a,b) => a.priority - b.priority)).catch(() => r.mx = []),
    dns.resolveTxt(domain).then(x => r.txt = x.map(rr => rr.join(''))).catch(() => r.txt = []),
    dns.resolveNs(domain).then(x => r.ns = x).catch(() => r.ns = []),
    dns.resolveCname(domain).then(x => r.cname = x).catch(() => r.cname = []),
  ])
  return { domain, ...r }
}

const handlers = { lookup, reverse, mx, txt, all }
const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')
rl.on('line', async (line) => {
  let req; try { req = JSON.parse(line) } catch { return }
  if (req.method === 'initialize') return out({ jsonrpc: '2.0', id: req.id, result: { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'dns-tools-mcp', version: '0.1.0' }}})
  if (req.method === 'tools/list') return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS }})
  if (req.method === 'tools/call') {
    try {
      const result = await handlers[req.params.name](req.params.arguments || {})
      out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(result) }]}})
    } catch (e) { out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }}) }
  }
})
