# MCP Server Pack — Buyer's Guide

Welcome. You bought the bundle that ships **10 production-ready MCP
servers** for Claude Code, Cursor, Cline, Windsurf, and any MCP-compatible
client. This README is the complete map of what you got and how to use it.

## What's in the box

```
mcp-server-pack/
├── README.md                  Public marketing README
├── BUYERS_README.md           This file
├── LICENSE                    MIT
├── servers/
│   ├── calc/                  ① Math + unit conversion
│   ├── time/                  ② Date/time/timezone utilities
│   ├── fs-search/             ③ File search + listing
│   ├── hn-search/             ④ HackerNews API
│   ├── arxiv/                 ⑤ arXiv search + abstracts
│   ├── regex/                 ⑥ Regex match/replace/explain
│   ├── json-tools/            ⑦ JSON validate, infer-schema, jq-lite
│   ├── markdown-tools/        ⑧ Markdown TOC, frontmatter, links
│   ├── wikipedia/             ⑨ Wikipedia search + summary
│   └── dns-tools/             ⑩ DNS lookup, reverse, MX, TXT
├── scripts/
│   └── install-all.sh         Generate unified Claude Code config
└── docs/
    └── PER_SERVER_NOTES.md    Per-server config + env vars
```

## 30-second install (all 10)

```bash
unzip mcp-server-pack-v1.0.zip
cd mcp-server-pack
bash scripts/install-all.sh > /tmp/claude-mcp-snippet.json
# Paste contents into ~/.claude/claude_desktop_config.json
```

Restart Claude Code. All 10 servers appear under the MCP icon.

## What each tool does

| Server | Tools | Use it for |
|---|---|---|
| `calc` | `eval`, `convert` | "what's 3 km in miles" / "what's sin(45 degrees)" |
| `time` | `now`, `parse`, `format`, `diff`, `ago`, `tz` | "convert 2026-05-04T14:00 UTC to Tokyo" |
| `fs-search` | `grep`, `find`, `tree` | "find all TODOs in this repo" |
| `hn-search` | `search`, `top`, `item` | "what's trending on HN about MCP" |
| `arxiv` | `search`, `abstract` | "find recent papers on QNLP" |
| `regex` | `match`, `replace`, `explain` | "explain this regex I found" |
| `json-tools` | `validate`, `infer-schema`, `query` | "infer a JSON Schema from this sample" |
| `markdown-tools` | `toc`, `frontmatter`, `links` | "extract all links from this README" |
| `wikipedia` | `search`, `summary` | "summary of Schrödinger's cat" |
| `dns-tools` | `lookup`, `reverse`, `mx`, `txt`, `all` | "what's the MX record for example.com" |

## Customizing

Each server is a single `index.mjs` file with no dependencies (except
`fs-search` which uses node:fs and `dns-tools` which uses node:dns).
Open the file, change the tool list, redeploy. Most servers are
50-150 lines.

## License

MIT. Use commercially. Modify freely. Resell the *individual servers*
freely (they're MIT licensed). Do NOT resell the bundle as a whole or
re-publish the BUYERS_README.

## Want auth + Stripe billing on top?

The companion guide [Build Your Own MCP Server With Auth + Billing](https://kempefire.gumroad.com/l/build-your-own-mcp)
walks you from "I have a working stdio server" → "I'm taking $29/mo
subscriptions for it." Same author, $29 on Gumroad.

## Support

Email lucas.kempe@icloud.com. Issues at
[github.com/LuuOW/mcp-server-pack](https://github.com/LuuOW/mcp-server-pack).
