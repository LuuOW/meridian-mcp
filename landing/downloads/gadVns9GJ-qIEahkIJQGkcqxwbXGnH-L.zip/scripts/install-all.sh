#!/usr/bin/env bash
# Bundle install — generates a unified Claude Code config snippet
# pointing at every server in this repo. Run from the repo root.

set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
echo "Generating Claude Code config snippet for all 10 servers under: $ROOT"
echo

cat <<EOF
Add the following to your Claude Code config (~/.claude/claude_desktop_config.json):

{
  "mcpServers": {
EOF

first=1
for dir in "$ROOT"/servers/*/; do
  name=$(basename "$dir")
  [ "$first" -eq 1 ] || echo ","
  first=0
  printf '    "%s": {\n      "command": "node",\n      "args":    ["%sindex.mjs"]\n    }' "$name" "$dir"
done
echo
cat <<EOF

  }
}

Then restart Claude Code. All 10 servers should appear under the MCP icon.
EOF
