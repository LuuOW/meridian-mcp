# Build Your Own MCP Server With Auth + Billing — In 30 Minutes

> Companion code + step-by-step guide for shipping a production-ready MCP server
> that has API keys, per-user quotas, Stripe checkout, and runs on Cloudflare's
> free tier. The same stack that powers [ask-meridian.uk](https://ask-meridian.uk).

**🎁 Get the full guide on Gumroad → [link goes here at launch]**

---

## What this is

Most MCP server tutorials show you `npx create-mcp` and a `Hello, world` tool.
That's not a server — that's a demo. Real MCP servers in production need:

- ✅ **Authentication** so random users can't drain your LLM bill
- ✅ **Per-key rate limits** so a paying user can't accidentally DoS themselves
- ✅ **Billing** because LLM tokens cost real money
- ✅ **Observability** so you know when something breaks
- ✅ **Edge deployment** because users run on the other side of the world

This repo gives you all of that, working, on Cloudflare's free tier (Workers,
KV, Pages Functions). The guide PDF walks you through every line of code.

## What's in the box

```
   guide/                Full step-by-step guide (Markdown + PDF on Gumroad)
   examples/
     stdio-shim/         5-KB stdio MCP wrapper, npm-publishable
     cf-workers-mcp/     Production HTTP backend with auth + billing + KV
   LICENSE-buyers-only/  Commercial use license (PDF buyers only)
   LICENSE               MIT — for the public examples
```

## Quick start (free public sample)

```bash
git clone https://github.com/LuuOW/build-your-own-mcp
cd build-your-own-mcp/examples/cf-workers-mcp
npm install
wrangler dev
```

Hits `http://localhost:8787/api/echo` and you're calling a working MCP-shaped
endpoint. The full guide ships the rest: auth, KV-backed quotas, Stripe
checkout flow, MCP Registry submission, custom domain wiring.

## Get the full guide

The complete 60-page guide + extended examples (Stripe webhook handler,
quota dashboard, Vectorize-backed cache, RAG layer) is on Gumroad:

**[Build Your Own MCP Server — $29 →](https://gumroad.com/l/build-your-own-mcp)**

License: MIT for code · Commercial-use OK · No reselling the guide PDF.

---

Built by [@LuuOW](https://github.com/LuuOW) · Same stack runs
[ask-meridian.uk](https://ask-meridian.uk) (live MCP server, registered
in the official MCP Registry).
