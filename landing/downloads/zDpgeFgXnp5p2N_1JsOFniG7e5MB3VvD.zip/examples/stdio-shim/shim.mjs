#!/usr/bin/env node
/**
 * byo-mcp-sample-shim — minimal MCP stdio shim.
 *
 * Reads JSON-RPC requests on stdin, forwards them to the HTTP backend
 * configured via env vars, writes JSON-RPC responses to stdout. This is
 * the "5-KB per-user install" pattern that lets your service appear in
 * Claude Code, Cursor, Windsurf etc. as an MCP server while the heavy
 * code lives on a server you control.
 *
 * Env vars:
 *   BYO_MCP_API_URL    upstream HTTP base, e.g. https://api.your-site.com
 *   BYO_MCP_API_KEY    optional bearer token (omit for free-tier IP cap)
 *
 * Full guide on Gumroad: https://gumroad.com/l/build-your-own-mcp
 */
import readline from 'node:readline'

const API_URL = process.env.BYO_MCP_API_URL || 'http://localhost:8787'
const API_KEY = process.env.BYO_MCP_API_KEY || ''

const TOOLS = [
  {
    name:        'echo',
    description: 'Echo a message back. Demo tool — replace with your own.',
    inputSchema: {
      type:       'object',
      properties: { msg: { type: 'string', description: 'message to echo' } },
      required:   ['msg'],
    },
  },
]

const rl = readline.createInterface({ input: process.stdin })
const out = (obj) => { process.stdout.write(JSON.stringify(obj) + '\n') }

rl.on('line', async (line) => {
  let req
  try { req = JSON.parse(line) }
  catch { return }

  if (req.method === 'initialize') {
    return out({
      jsonrpc: '2.0', id: req.id,
      result: {
        protocolVersion: '2025-06-18',
        capabilities:    { tools: {} },
        serverInfo:      { name: 'byo-mcp-sample-shim', version: '0.1.0' },
      },
    })
  }

  if (req.method === 'tools/list') {
    return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS } })
  }

  if (req.method === 'tools/call' && req.params?.name === 'echo') {
    try {
      const headers = { 'content-type': 'application/json' }
      if (API_KEY) headers.authorization = `Bearer ${API_KEY}`
      const r = await fetch(`${API_URL}/api/protected`, {
        method: 'POST', headers,
        body:   JSON.stringify({ msg: req.params.arguments?.msg || '' }),
      })
      const data = await r.json()
      if (!r.ok) {
        return out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: data.error || 'upstream error' } })
      }
      return out({
        jsonrpc: '2.0', id: req.id,
        result: { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] },
      })
    } catch (e) {
      return out({ jsonrpc: '2.0', id: req.id, error: { code: -32603, message: e.message } })
    }
  }

  // Unknown method — respond with method-not-found per JSON-RPC.
  if (typeof req.id !== 'undefined') {
    out({ jsonrpc: '2.0', id: req.id, error: { code: -32601, message: 'method not found' } })
  }
})
