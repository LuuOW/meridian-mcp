# byo-mcp-sample-shim

Minimal MCP stdio shim that proxies to your HTTP backend. Public sample
from [build-your-own-mcp](https://github.com/LuuOW/build-your-own-mcp).

## Use

```bash
npm install -g byo-mcp-sample-shim
BYO_MCP_API_URL=https://your-worker.example.workers.dev byo-mcp-sample-shim
```

Or in Claude Code's config:

```json
{
  "mcpServers": {
    "byo-mcp-sample": {
      "command": "npx",
      "args":    ["-y", "byo-mcp-sample-shim"],
      "env":     { "BYO_MCP_API_URL": "https://your-worker.example.workers.dev" }
    }
  }
}
```

## Want the production version?

This shim has one tool (`echo`) and no auth UI. The
[full guide on Gumroad](https://gumroad.com/l/build-your-own-mcp) ships:

- Multiple tools wired to your HTTP backend
- API key issuance via Stripe checkout
- Per-key quota with `X-…-Calls-Remaining` headers
- Auto-refresh logic + error retries
- npm publish workflow + version tagging
- Submission to the official MCP Registry

Built by [@LuuOW](https://github.com/LuuOW). Same shim pattern powers
[ask-meridian.uk](https://ask-meridian.uk).
