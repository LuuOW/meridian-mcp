/**
 * cf-workers-mcp-sample — minimal production-shaped MCP HTTP backend.
 *
 * Endpoints (sample only — buyers get the full implementation guide):
 *
 *   GET  /                  banner JSON (proof the worker is alive)
 *   GET  /api/echo?msg=…    public, no auth, returns the message
 *   POST /api/protected     requires `Authorization: Bearer mrd_test_…`
 *                           (validates against MCP_KV). Free tier: 10/day per IP.
 *   GET  /api/quota         current per-IP and per-key remaining quota
 *
 * The full Gumroad guide adds:
 *   - Stripe checkout + webhook + key issuance
 *   - Per-key monthly quotas (vs per-IP daily)
 *   - MCP server registration metadata
 *   - Vectorize-backed result caching
 *   - SSE streaming pipeline
 *   - Observability via AI Gateway
 */

interface Env {
  MCP_KV: KVNamespace
  FREE_TIER_DAILY_PER_IP: string
  SERVICE_NAME: string
}

const corsHeaders = {
  'access-control-allow-origin':  '*',
  'access-control-allow-methods': 'GET, POST, OPTIONS',
  'access-control-allow-headers': 'authorization, content-type',
}

function json(body: unknown, init: ResponseInit = {}) {
  return new Response(JSON.stringify(body, null, 2), {
    ...init,
    headers: { 'content-type': 'application/json', ...corsHeaders, ...(init.headers || {}) },
  })
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders })

    const url = new URL(request.url)
    const ip  = request.headers.get('cf-connecting-ip') || 'unknown'

    // ── /
    if (url.pathname === '/') {
      return json({
        service:   env.SERVICE_NAME,
        version:   '0.1.0',
        endpoints: ['/api/echo', '/api/protected', '/api/quota'],
        guide:     'https://gumroad.com/l/build-your-own-mcp',
      })
    }

    // ── /api/echo  (public sample)
    if (url.pathname === '/api/echo') {
      const msg = url.searchParams.get('msg') || 'hello from a Cloudflare Worker'
      return json({ msg, your_ip: ip, served_by: 'cf-workers-mcp-sample' })
    }

    // ── /api/quota
    if (url.pathname === '/api/quota') {
      const limit = parseInt(env.FREE_TIER_DAILY_PER_IP, 10) || 10
      const dkey  = `free:${ip}:${new Date().toISOString().slice(0, 10)}`
      const used  = parseInt((await env.MCP_KV.get(dkey)) || '0', 10)
      return json({ ip, daily_limit: limit, used, remaining: Math.max(0, limit - used) })
    }

    // ── /api/protected  (requires Authorization OR free-tier IP cap)
    if (url.pathname === '/api/protected' && request.method === 'POST') {
      const auth = request.headers.get('authorization') || ''
      if (auth.startsWith('Bearer ')) {
        const token = auth.slice(7).trim()
        const record = await env.MCP_KV.get(`key:${token}`, 'json')
        if (!record) return json({ error: 'invalid api key' }, { status: 401 })
        // (full guide: validate plan, check monthly quota, increment counter)
      } else {
        // anonymous → free-tier per-IP cap
        const limit = parseInt(env.FREE_TIER_DAILY_PER_IP, 10) || 10
        const dkey  = `free:${ip}:${new Date().toISOString().slice(0, 10)}`
        const used  = parseInt((await env.MCP_KV.get(dkey)) || '0', 10)
        if (used >= limit) {
          return json({ error: `free tier exhausted (${limit}/day per IP). Pay $29 for the guide showing how to wire Stripe.` }, { status: 429 })
        }
        await env.MCP_KV.put(dkey, String(used + 1), { expirationTtl: 90000 })
      }

      const body = await request.json().catch(() => ({}))
      return json({
        ok:        true,
        echoed:    body,
        note:      'This is the public sample. The full guide on Gumroad shows the production flow: API key issuance via Stripe webhook, monthly quota tracking, and the MCP-protocol-compliant tool/resource handlers.',
      })
    }

    return json({ error: 'not found' }, { status: 404 })
  },
}
