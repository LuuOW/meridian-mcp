# 12. Bonus: Vectorize-backed result caching

KV cache is exact-match — same query → same response. **Vectorize** is
semantic — similar query → cached response (within a similarity threshold).
Hugely powerful for natural-language queries where users phrase the same
intent ten different ways.

## Setup (one-time)

```bash
wrangler vectorize create my-cache --dimensions=1024 --metric=cosine
```

Then bind it in `wrangler.toml`:

```toml
[[vectorize]]
binding    = "VECTORIZE"
index_name = "my-cache"
```

## Embedding via Workers AI

Workers AI ships several embedding models for free:

```typescript
async function embed(env: Env, text: string): Promise<number[]> {
  const out = await env.AI.run('@cf/baai/bge-m3', { text: [text] })
  return out.data[0]   // 1024-dim float vector
}
```

`@cf/baai/bge-m3` is multilingual, 1024-dim, and is on the free tier.
Use it for both queries and corpus.

## Lookup-then-LLM pattern

```typescript
async function semanticCacheGet(env: Env, query: string) {
  const qVec    = await embed(env, query)
  const matches = await env.VECTORIZE.query(qVec, { topK: 1, returnMetadata: true })
  if (matches.matches.length && matches.matches[0].score >= 0.92) {
    // Cache hit — return the previously-cached response
    return matches.matches[0].metadata
  }
  return null
}

async function semanticCachePut(env: Env, query: string, response: any) {
  const qVec = await embed(env, query)
  await env.VECTORIZE.upsert([{
    id:       crypto.randomUUID(),
    values:   qVec,
    metadata: response,
  }])
}
```

In your handler:

```typescript
const cached = await semanticCacheGet(env, task)
if (cached) return json({ ...cached, cache_type: 'semantic' })

const fresh  = await callLLM(task)
await semanticCachePut(env, task, fresh)
return json(fresh)
```

## Threshold tuning

The `0.92` cosine similarity threshold is the load-bearing knob:

- **>0.95** — only near-duplicate paraphrases hit. Conservative, low
  collateral, low cache hit rate.
- **0.92** — moderately similar wording hits. Reasonable default for
  open-domain tasks.
- **0.85** — broad. Fast cache, but risk of returning a cached response
  for a "looks similar but means something different" query.

Start at 0.92, monitor via AI Gateway logs, tune.

## Beyond caching: RAG

Once you have an index of past (query → response) pairs, you can also
USE it as RAG context for new queries:

```typescript
const matches = await env.VECTORIZE.query(qVec, { topK: 3 })
const ragContext = matches.matches.map(m => m.metadata.summary).join('\n')

const llmResponse = await callLLM(task, {
  systemAddendum: `Similar past queries returned:\n${ragContext}\n\nUse for inspiration only — author fresh response.`
})
```

This makes your service LEARN from itself over time. Without changing the
LLM, the quality + consistency of responses grows as the index accumulates.
Real production RAG with ~50 lines of code.

## Storage costs

Vectorize is free up to:

- 30 million stored vectors
- 50 million queried vectors per month

For an MCP server with 10k unique queries/month, you'll never come close.
Even at 1M queries/month, you're solidly in free tier.

## Beyond Vectorize

If you want to migrate later (multi-cloud, cheaper, etc.):

- [Upstash Vector](https://upstash.com/docs/vector) — Redis-flavoured,
  generous free tier, similar API
- [Pinecone](https://www.pinecone.io) — paid from day 1 but battle-tested
- [pgvector](https://github.com/pgvector/pgvector) — Postgres extension,
  self-host, no SaaS

The Vectorize binding API is small enough (`upsert`, `query`, `getByIds`,
`deleteByIds`) that wrapping it in a thin adapter makes any future
migration a one-day task. The buyer bundle ships `_vector.ts` exactly
this way.

---

# Closing

You shipped a production MCP server. Auth works. Billing works. Quotas
work. It's listed in the registry. It scales to 100k requests/day on the
free tier and the upgrade path costs $5/month per million extra calls.

Three things to do next:

1. **Replace `echo` with your real tool**. The whole guide assumed `echo`
   as a stand-in. Your actual value comes from what you replace it with.
2. **Watch the AI Gateway dashboard for the first week**. Surprises live
   there — slow upstream responses, expensive token-burn, abuse patterns.
3. **Talk to your first 5 paying users.** Email each of them. Ask what
   they hate. The first 5 customers tell you what your real product is.

Good luck. Send a screenshot of your first sale to
[lucas.kempe@icloud.com](mailto:lucas.kempe@icloud.com) — I keep a wall.
