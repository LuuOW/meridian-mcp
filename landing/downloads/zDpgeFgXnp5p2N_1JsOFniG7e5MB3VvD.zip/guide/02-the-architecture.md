# 2. The architecture you're going to ship

```
                                ┌──────────────────────────────┐
                                │ Claude Code / Cursor / Cline │
                                │ Windsurf / any MCP client    │
                                └─────────────┬────────────────┘
                                              │ stdio JSON-RPC
                                              ▼
                                ┌──────────────────────────────┐
                                │ npm-installable shim         │  ~5 KB
                                │ byo-mcp-foo-shim             │  user runs
                                │ (forwards every call over    │  on their
                                │  HTTPS to your backend)      │  laptop
                                └─────────────┬────────────────┘
                                              │ HTTPS POST
                                              │ Authorization: Bearer …
                                              ▼
   ┌──────────────────────────────────────────────────────────┐
   │  your-mcp.example.com  (Cloudflare DNS, proxied)         │
   └────────────────────────┬─────────────────────────────────┘
                            ▼
   ┌──────────────────────────────────────────────────────────┐
   │  Cloudflare Worker / Pages Function                       │
   │  - reads bearer token, validates against KV               │
   │  - per-IP free tier rate limit (KV counter)               │
   │  - forwards to LLM (Anthropic / Workers AI / Groq)        │
   │  - emits Stripe webhook for new subscriptions             │
   └────────┬──────────────────────────┬──────────────────────┘
            │                          │
            ▼                          ▼
   ┌────────────────┐         ┌────────────────────────────────┐
   │ Cloudflare KV  │         │  Stripe                         │
   │ key:HASH       │         │  Checkout · Customer Portal     │
   │ free:IP:DAY    │         │  Webhooks → /api/stripe/webhook │
   │ session:SID    │         └────────────────────────────────┘
   └────────────────┘
```

Three boxes, all on free or near-free tiers:

| Box | Provider | Free-tier ceiling |
|---|---|---|
| Static + Functions | Cloudflare Pages + Workers | 100k requests/day, 10ms CPU each |
| Key + quota store | Cloudflare KV | 100k reads/day, 1k writes/day |
| Payments | Stripe | 2.9% + 30¢ per charge (no fixed monthly cost) |

For an MCP server with 100 paying users at $29/mo, this stack costs you literally
$0 in hosting and earns you $2,900/mo. The economics break favourably long before
you'd ever need to think about a different host.

## What a request looks like end to end

1. User in Claude Code says "use my-tool to do X"
2. Claude Code resolves `my-tool` → the npm-installed shim, which is already
   speaking JSON-RPC over its own stdin/stdout
3. Shim wraps the call as `{ "method": "tools/call", "params": { ... } }` and
   sends to your Worker as an HTTPS POST with the user's API key in the
   Authorization header
4. Your Worker:
   - validates the bearer token against `key:HASH` in KV
   - increments their monthly counter (`monthly:HASH:YYYYMM`)
   - if free tier (no bearer), checks `free:IP:DAY < limit`
   - calls upstream LLM (or computes locally)
   - returns JSON
5. Shim wraps the JSON response back into the JSON-RPC format Claude Code expects
6. Claude Code shows the result to the user

The whole round trip is typically 100-300 ms when the LLM is local (Groq is ~5 s
for a real generation, Anthropic ~10-30 s, Workers AI ~30-60 s).

## Why each piece is where it is

- **Shim on user's laptop** — because MCP clients don't speak HTTPS directly;
  they expect JSON-RPC over stdio. The shim is the translation layer.
- **Worker** — because edge isolates start in <5 ms and there's no cold-start
  fee. You can have 1000s of users in different time zones without spinning up
  servers.
- **KV** — because we just need O(1) lookups by key (api_key → user_record),
  not relational queries. KV is also free up to a generous threshold.
- **Stripe** — because they handle PCI compliance, dispute handling, tax in 30+
  jurisdictions, and currency conversion. Charging $29 to credit cards yourself
  is a worse use of your time than building features.

Continue with [`03-cloudflare-account-first-deploy.md`](./03-cloudflare-account-first-deploy.md).
