# 8. Submitting to the official MCP Registry

The official Model Context Protocol Registry at `registry.modelcontextprotocol.io`
is the canonical discovery surface for MCP servers — Claude Code, Cursor, etc.
will eventually all read from it. Getting listed is a one-time ~10-minute job
and produces compounding traffic.

## Prerequisites

- Your server published to npm under a stable name
- A `server.json` file in the **root** of your repo
- A GitHub repo (the registry pulls metadata from it)

## Write `server.json`

This is the meta-manifest the registry indexes:

```json
{
  "$schema":     "https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json",
  "name":        "io.github.YourGitHubUser/your-server-name",
  "description": "One sentence, ≤100 chars, that says what the server does.",
  "repository":  {
    "url":    "https://github.com/YourGitHubUser/your-repo",
    "source": "github"
  },
  "version":     "1.0.0",
  "packages":    [
    {
      "registryType": "npm",
      "identifier":   "your-shim-package-name",
      "version":      "1.0.0",
      "transport":    { "type": "stdio" },
      "environmentVariables": [
        {
          "name":        "BYO_MCP_API_URL",
          "default":     "https://your-mcp.example.com",
          "description": "The HTTPS backend URL the shim forwards to.",
          "required":    false
        },
        {
          "name":        "BYO_MCP_API_KEY",
          "isSecret":    true,
          "description": "Pro/Team API key. Omit for free tier.",
          "required":    false
        }
      ]
    }
  ]
}
```

A few things to know:

- **Description is hard-capped at 100 chars.** Counted server-side; if you go
  over, the publish call returns "expected length <= 100".
- **The `name` field uses reverse-DNS style.** `io.github.LuuOW/meridian-skills`
  is the format. The first segment is your namespace, the second is the slug.
- **Versions must be SemVer.** `1.0.0`, not `v1.0.0` or `1.0`.
- **Don't include a `remotes` block** unless you actually expose an HTTP MCP
  endpoint on the public internet (most stdio servers don't — the shim is the
  user-facing entry point, not the HTTP backend).

## Install the publisher

```bash
npm install -g @modelcontextprotocol/mcp-publisher
mcp-publisher login github     # opens browser, authorizes
mcp-publisher validate         # lints server.json
mcp-publisher publish          # POSTs to registry.modelcontextprotocol.io
```

`validate` will fail loudly on schema violations. Common ones:

- description >100 chars
- name not following the reverse-DNS pattern
- version not SemVer
- `repository.source` not in {github, gitlab}

## After publishing

Within a few minutes:

```bash
curl https://registry.modelcontextprotocol.io/v0/servers?search=your-server | jq '.servers'
```

Should return your entry with `isLatest: true`. From here, MCP clients that
support registry discovery will surface your server in their search UIs.

## Cross-list on awesome-mcp-servers

[github.com/punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers)
is a community-maintained README that indexes thousands of servers by
category. Open a PR adding your row in the appropriate section:

```markdown
- [your-server-name](https://github.com/yourname/your-repo) 🤖🤖🤖 — One sentence describing what it does.
```

The 🤖🤖🤖 emoji marks "agent fast-track" and is reserved for servers
explicitly designed to be agent-callable. The PR usually merges within a
few days.

## Cross-list on mcp.so

[mcp.so](https://mcp.so) is a directory + search engine for MCP servers.
There's a submission form at the top of their page. Fewer SEO benefits than
the official registry, but they get organic Google traffic.

## What this gets you

- Your server appears in MCP-aware client search UIs (Claude Code's
  upcoming registry browser, similar features in Cursor/Cline)
- Awesome-list cross-listing gets you GitHub stars from people browsing
  the README
- mcp.so adds long-tail SEO

Combined, these are passive distribution channels that work for years
after one afternoon of submission.

Continue with [`09-production-gotchas.md`](./09-production-gotchas.md).
