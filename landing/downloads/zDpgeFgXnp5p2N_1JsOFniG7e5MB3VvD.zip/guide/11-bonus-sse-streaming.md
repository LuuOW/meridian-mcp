# 11. Bonus: SSE streaming for live progress events

Server-Sent Events (SSE) is HTTP/1.1's "long-lived response that delivers
events as they happen". One-direction, text-based, simple. Perfect for
"here's what the LLM is generating right now" UIs.

## When to use it

- Long LLM calls (5-30 seconds) where users need feedback
- Multi-stage pipelines (cache lookup → embed → LLM → classify → done)
  where each stage takes meaningful time
- Anything where the user otherwise stares at a spinner

When NOT to use it: short responses (< 1s); MCP clients that can't render
intermediate output (most stdio MCP clients can't stream tool output, so
this only helps if you're also serving a web UI on the same backend).

## The wire format

```
event: progress
data: {"stage": "cache_miss"}

event: progress
data: {"stage": "llm_streaming", "chars": 1234, "ms": 5234}

event: skill
data: {...full classified skill...}

event: done
data: {...summary fields...}
```

Each block is `event: NAME\ndata: JSON\n\n`. Blank line ends one event.
JSON-encode every payload to keep newlines from breaking the framing.

## Server-side in a Worker

```typescript
const enc = new TextEncoder()
const { readable, writable } = new TransformStream()
const writer = writable.getWriter()

const send = async (event, data) => {
  await writer.write(enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
}

// Run the pipeline async — the readable goes back to the user immediately
;(async () => {
  try {
    await send('progress', { stage: 'cache_miss' })
    await send('progress', { stage: 'llm_streaming', chars: 100 })
    // ...
    await send('done', { ok: true })
  } catch (e) {
    await send('error', { message: e.message })
  } finally {
    await writer.close()
  }
})()

return new Response(readable, { headers: {
  'content-type':              'text/event-stream; charset=utf-8',
  'cache-control':             'no-cache, no-transform',
  'x-accel-buffering':         'no',
  'access-control-allow-origin': '*',
}})
```

## Client-side consumer (vanilla fetch + ReadableStream)

EventSource doesn't support POST or custom headers, so most real apps use
fetch + manual SSE parsing:

```javascript
const res = await fetch('/api/route?stream=1', {
  method:  'POST',
  headers: { accept: 'text/event-stream', 'content-type': 'application/json' },
  body:    JSON.stringify({ task })
})
const reader = res.body.getReader()
const dec    = new TextDecoder()
let buf      = ''
while (true) {
  const { value, done } = await reader.read()
  if (done) break
  buf += dec.decode(value, { stream: true })
  let idx
  while ((idx = buf.indexOf('\n\n')) !== -1) {
    const msg = buf.slice(0, idx)
    buf       = buf.slice(idx + 2)
    let event = 'message'
    const dataLines = []
    for (const line of msg.split('\n')) {
      if (line.startsWith('event:'))      event = line.slice(6).trim()
      else if (line.startsWith('data:'))  dataLines.push(line.slice(5).trim())
    }
    if (dataLines.length) {
      const payload = JSON.parse(dataLines.join('\n'))
      handleEvent(event, payload)
    }
  }
}
```

## Forwarding upstream LLM streams

Groq, OpenAI, Anthropic all support `stream: true` and emit OpenAI-format
SSE. To forward to your end users:

```javascript
const groq = await fetch('https://api.groq.com/...', {
  body: JSON.stringify({ ..., stream: true })
})

for await (const delta of iterOpenAIStream(groq)) {
  rawText += delta
  // Throttle progress events to avoid overloading the client
  if (Date.now() - lastSent > 250) {
    await send('progress', { chars: rawText.length })
    lastSent = Date.now()
  }
}
```

Where `iterOpenAIStream` is a small async generator that parses OpenAI's
SSE format. ~30 lines, included in the buyer bundle as `_stream.ts`.

## Common pitfalls

- **Backpressure in tests** — Node's TransformStream has a high-water
  mark of 1. If your test does `await send()` before the consumer reads,
  it blocks. Always launch reader concurrently with writer.
- **Proxy buffering** — Some HTTP intermediaries (nginx) buffer SSE by
  default. The `x-accel-buffering: no` header tells nginx not to. CF
  doesn't buffer SSE.
- **Cancellation** — If the user closes the tab mid-stream, your Worker
  keeps running. Listen for `request.signal` aborted events (or just
  let it finish — small Worker invocations are cheap).

Continue with [`12-bonus-vectorize-cache.md`](./12-bonus-vectorize-cache.md).
