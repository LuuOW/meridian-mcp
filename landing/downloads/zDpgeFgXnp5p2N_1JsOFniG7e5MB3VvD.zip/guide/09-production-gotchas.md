# 9. Production gotchas

Things that look fine in dev and bite in production.

## KV propagation latency

Cloudflare KV is **eventually consistent**. A `put` from the IAD edge can
take ~60s to be visible at SYD. This breaks two patterns:

1. **"Did the user just pay yet"** — your webhook handler writes
   `key:HASH` from one edge; the user's first protected call from another
   edge sees nothing. Result: brand-new buyer gets a 401.

   Fix: in the claim endpoint, return a temporary "session-bound" key
   that's stored under the local edge's key (using `cacheTtl`), so the
   first request immediately after checkout works.

2. **Updating a user's plan** — they upgraded to Team. The first request
   they make might still be rate-limited under the Pro cap.

   Fix: don't read-then-write per request. Read the rec once at request
   time, accept the small staleness, log it.

## Worker CPU time limit

Free tier: **10 ms CPU per request**. Paid tier: **50 ms**. CPU time =
the time spent executing your code, NOT including waits on `fetch()`,
`KV.get()`, etc. Those are I/O and don't count.

Where you'll hit this:

- Heavy JSON parsing on big responses (>50 KB)
- Crypto: SHA-256 of a small string is fine, hashing 10 MB is not
- Loops over thousands of array items

What to do:

- For long compute, use a Worker with `unbound` CPU limits (paid plan)
- For really long compute, use Workers Queues + a separate consumer
- For one-off heavy jobs, return immediately and process in the background
  via `ctx.waitUntil(promise)`

## Bundle size

Free Workers cap at **1 MB compressed** bundle. The official `stripe` npm
package is ~700 KB by itself; `openai` SDK is ~400 KB. Adding both =
over the limit.

Fixes:

- Use raw `fetch()` to upstream APIs instead of SDKs (it's how the buyer
  bundle's `_stripe.ts` works — 25 LoC vs 700 KB)
- Tree-shake aggressively (esbuild does this by default)
- Move heavy logic to a Worker hosted at `unbound` plan if you really need
  the SDKs

## Webhook retries

Stripe retries failed webhooks for up to 3 days at exponential backoff. If
your handler returns anything other than 2xx, it WILL retry. Two failure
modes:

1. **Non-idempotent handlers** — if processing the same event twice
   creates two API keys, you're going to have a bad time. Always use the
   event's `id` as a dedup key:

   ```typescript
   const dedup = await env.MCP_KV.get(`webhook:${event.id}`)
   if (dedup) return new Response('already processed')
   await env.MCP_KV.put(`webhook:${event.id}`, '1', { expirationTtl: 86400 * 7 })
   // ... process
   ```

2. **Synchronous LLM calls in webhook handler** — if you do something
   slow inside the handler, Stripe might time out (20s limit) and retry.
   Always: do the small synchronous bookkeeping (write to KV), then
   `ctx.waitUntil()` the slow stuff.

## CORS in browser-launched checkout

If your landing page is on `your-mcp.example.com` and you POST to
`/api/stripe/checkout` on the same origin, no CORS needed. If you embed
the checkout button on a different origin, your Worker must:

```typescript
if (request.method === 'OPTIONS') {
  return new Response(null, { status: 204, headers: {
    'access-control-allow-origin':  '*',
    'access-control-allow-methods': 'POST, GET, OPTIONS',
    'access-control-allow-headers': 'content-type, authorization',
    'access-control-max-age':       '86400',
  }})
}
```

## Free-tier abuse

People will:

- Cycle through residential IPs (use a CGNAT, mobile hotspot, etc.) to
  evade your per-IP cap
- Use Tor (where every exit IP has a DIFFERENT user behind it, so your
  cap unfairly blocks them)
- Use VPNs (similar to above)

You'll never block 100% of abuse on the free tier. The goal is not zero
abuse — the goal is friction high enough that it's easier to pay $29.

If a specific IP/range becomes a problem, block it via Cloudflare's
firewall rules (free, point-and-click in the dashboard).

## Stripe Test mode → Live mode

The transition is one toggle in the dashboard. After flipping:

- All your `sk_test_…` and `pk_test_…` keys stop working
- You get new `sk_live_…` and `pk_live_…` keys
- Test products + prices DON'T migrate; you have to recreate them in Live
- Test customers + subscriptions don't migrate either

Plan a launch checklist:

```
   [ ] Switch dashboard to Live mode
   [ ] Recreate Pro and Team products with same names
   [ ] Copy new price IDs
   [ ] wrangler secret put STRIPE_SECRET_KEY (the live one)
   [ ] wrangler secret put STRIPE_PRICE_PRO  (the new live ID)
   [ ] wrangler secret put STRIPE_PRICE_TEAM
   [ ] Update webhook endpoint to point at live secret
   [ ] wrangler secret put STRIPE_WEBHOOK_SECRET (live)
   [ ] Test with a real $1 charge (use a test plan you can refund)
   [ ] Refund yourself
   [ ] Announce
```

Continue with [`10-llm-cost-safe.md`](./10-llm-cost-safe.md).
