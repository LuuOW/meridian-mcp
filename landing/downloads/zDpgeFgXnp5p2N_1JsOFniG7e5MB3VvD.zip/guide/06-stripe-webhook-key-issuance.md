# 6. API-key issuance via Stripe webhook (5 min)

A buyer just paid. We need to:

1. Generate an API key, e.g. `mrd_live_abc123…`
2. Store the key's hash + the buyer's plan + their Stripe customer ID in KV
3. Show the plain-text key to the buyer **once** (they save it)
4. From now on, every request the buyer makes carries the key in
   `Authorization: Bearer …` and we look up the hash in KV

The flow has two parts: the **webhook** (Stripe → us, async, can retry) and
the **claim endpoint** (buyer → us, sync, fires after redirect).

## Generate keys

```typescript
function generateKey(): string {
  // 32 random bytes = 256 bits. Web Crypto in Workers gives us this for free.
  const bytes = crypto.getRandomValues(new Uint8Array(32))
  // base64url is URL-safe; use it so users can paste keys into env vars
  // without quoting issues.
  const b64 = btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '')
  return `mrd_live_${b64}`
}

async function hashKey(key: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(key))
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('')
}
```

Why hash? Because if your KV gets dumped (insider threat, misconfiguration,
SDK bug), the leaked data shouldn't include working tokens. We only ever
store the SHA-256.

## The webhook (the source of truth)

Stripe POSTs to whatever URL you configure under
**Developers → Webhooks → Add endpoint**. Set the URL to
`https://your-mcp.example.com/api/stripe/webhook` and select event
`checkout.session.completed` (and optionally
`customer.subscription.deleted` for cancellations).

Save and copy the **signing secret** — `whsec_…`. Store as Worker secret:

```bash
wrangler secret put STRIPE_WEBHOOK_SECRET
```

The handler:

```typescript
if (url.pathname === '/api/stripe/webhook' && request.method === 'POST') {
  const sig    = request.headers.get('stripe-signature') || ''
  const body   = await request.text()
  if (!await verifySig(body, sig, env.STRIPE_WEBHOOK_SECRET)) {
    return new Response('bad signature', { status: 400 })
  }
  const event  = JSON.parse(body)
  if (event.type === 'checkout.session.completed') {
    const s    = event.data.object
    const plan = s.metadata?.plan || 'pro'
    const key  = generateKey()
    const hash = await hashKey(key)
    await env.MCP_KV.put(`key:${hash}`, JSON.stringify({
      plan,
      customer_id:    s.customer,
      monthly_limit:  plan === 'team' ? 100000 : 10000,
      created_at:     Date.now(),
    }))
    // Stash the plain key under the session ID, short TTL — only
    // the buyer's redirect needs it
    await env.MCP_KV.put(`session:${s.id}`, key, { expirationTtl: 1800 })
  }
  return new Response('ok')
}
```

Verify the signature properly (Stripe uses HMAC-SHA-256 with a timestamp +
body). The buyer bundle has a tested 25-line `verifySig` implementation
under `examples/cf-workers-mcp-full/src/_stripe.ts`.

## The claim endpoint (the user-facing page)

After paying, the user lands on:

```
https://your-mcp.example.com/api/stripe/claim?session_id=cs_test_…
```

Handler:

```typescript
if (url.pathname === '/api/stripe/claim') {
  const sid = url.searchParams.get('session_id') || ''
  const key = await env.MCP_KV.get(`session:${sid}`)
  if (!key) return json({ error: 'session not found or already claimed' }, { status: 404 })
  await env.MCP_KV.delete(`session:${sid}`)
  // Return an HTML page (so the user sees + copies the key in their browser)
  return new Response(`
    <!DOCTYPE html><meta charset="utf-8">
    <h1>Welcome to Pro 🎉</h1>
    <p>Your API key (shown only once — save it now):</p>
    <code style="display:block;padding:12px;background:#eee">${key}</code>
    <p>Set it in your shim:
       <code>BYO_MCP_API_KEY=${key}</code></p>
  `, { headers: { 'content-type': 'text/html' }})
}
```

That's the full happy path. The buyer pays, gets a key shown once, copies
it into their config, and from then on every shim → backend call carries
the bearer.

## Validating keys on every protected request

Update `/api/protected`:

```typescript
const auth = request.headers.get('authorization') || ''
if (!auth.startsWith('Bearer ')) return json({ error: 'auth required' }, { status: 401 })
const key  = auth.slice(7).trim()
const hash = await hashKey(key)
const rec  = await env.MCP_KV.get(`key:${hash}`, 'json') as KeyRecord | null
if (!rec) return json({ error: 'invalid key' }, { status: 401 })

// Monthly quota
const monthKey = `monthly:${hash}:${new Date().toISOString().slice(0, 7).replace('-','')}`
const used     = parseInt(await env.MCP_KV.get(monthKey) || '0', 10)
if (used >= rec.monthly_limit) {
  return json({ error: 'monthly quota exhausted' }, { status: 429 })
}
await env.MCP_KV.put(monthKey, String(used + 1), { expirationTtl: 32 * 86400 })
```

Headers worth setting on success so the user knows where they stand:

```typescript
return json(result, {
  headers: {
    'x-meridian-plan':            rec.plan,
    'x-meridian-calls-remaining': String(rec.monthly_limit - used - 1),
  },
})
```

## What you have now

- Real users can pay you real money with a real credit card
- They get a key shown once, hashed at rest
- Every API call validates + counts down from their monthly quota
- All on Cloudflare's free tier
- Total code added today: ~150 lines

Continue with [`07-the-stdio-shim.md`](./07-the-stdio-shim.md).
