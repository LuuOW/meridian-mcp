# 5. Stripe account + the $29/mo Pro tier (10 min)

## Sign up + activate

[stripe.com/register](https://stripe.com/register). Sign up with the email
you want to receive money at. After confirming, Stripe asks for business
details — you can defer this in **Test mode** but you can't accept real
money until you Activate (which involves SSN/tax-ID/business address; takes
~5 minutes).

For this chapter, stay in Test mode. We'll flip to Live mode at the end.

## Create the product + price

Dashboard → **Products** → **+ Add Product**.

```
   Name:        Pro Tier
   Description: 10,000 tool calls per month for [your service name]
   Image:       (optional, but increases checkout conversion ~5%)

   Pricing:
     Recurring · Monthly · USD $29.00
```

Click **Save**. On the product page you'll see a `price_…` ID — copy it.
That's the value you'll set as the env var `STRIPE_PRICE_PRO`.

Repeat for any other tiers (Team $99, etc.).

## Get the API keys

Dashboard → **Developers** → **API keys**.

You need two:

| Key | Format | Where it goes |
|---|---|---|
| **Secret key** | `sk_test_…` (test mode) → `sk_live_…` (live) | Worker secret: `wrangler secret put STRIPE_SECRET_KEY` |
| **Publishable key** | `pk_test_…` → `pk_live_…` | Front-end JS, can be in the source |

Set the secret on your Worker:

```bash
wrangler secret put STRIPE_SECRET_KEY
# (paste the sk_test_… value when prompted)

wrangler secret put STRIPE_PRICE_PRO
# (paste the price_… ID)
```

Verify they're set:

```bash
wrangler secret list
# [{"name":"STRIPE_SECRET_KEY","type":"secret_text"},
#  {"name":"STRIPE_PRICE_PRO","type":"secret_text"}]
```

## The Checkout Session endpoint

Add this to `src/index.ts`:

```typescript
if (url.pathname === '/api/stripe/checkout' && request.method === 'POST') {
  const stripe = new Stripe(env.STRIPE_SECRET_KEY)   // see below
  const session = await stripe.checkout.sessions.create({
    mode:        'subscription',
    line_items:  [{ price: env.STRIPE_PRICE_PRO, quantity: 1 }],
    success_url: 'https://your-mcp.example.com/api/stripe/claim?session_id={CHECKOUT_SESSION_ID}',
    cancel_url:  'https://your-mcp.example.com/cancel',
    metadata:    { plan: 'pro' },
  })
  return json({ url: session.url })
}
```

There are two ways to call Stripe from a Worker:

**Option A: the official `stripe` npm package.**
~700 KB minified, eats into your Worker bundle limit (1 MB free, 10 MB paid).
Heaviest path, but identical to a Node app.

**Option B: raw `fetch` to Stripe's REST API.**
~50 lines of code, no dependency. Recommended for Workers.

The buyer bundle ships option B. Here's the gist:

```typescript
async function stripeAPI(env: Env, path: string, body?: Record<string, string>) {
  const r = await fetch(`https://api.stripe.com/v1${path}`, {
    method: body ? 'POST' : 'GET',
    headers: {
      'Authorization': `Bearer ${env.STRIPE_SECRET_KEY}`,
      'Content-Type':  'application/x-www-form-urlencoded',
    },
    body: body ? new URLSearchParams(body).toString() : undefined,
  })
  if (!r.ok) throw new Error(`Stripe ${r.status}: ${await r.text()}`)
  return r.json()
}

// Create the checkout session — Stripe wants square-bracket-notation for
// arrays, so we manually flatten line_items
const session = await stripeAPI(env, '/checkout/sessions', {
  mode:                       'subscription',
  'line_items[0][price]':     env.STRIPE_PRICE_PRO,
  'line_items[0][quantity]':  '1',
  success_url:                `${BASE}/api/stripe/claim?session_id={CHECKOUT_SESSION_ID}`,
  cancel_url:                 `${BASE}/cancel`,
  'metadata[plan]':           'pro',
})
return json({ url: session.url })
```

## Trigger checkout from your landing page

```html
<button id="buy" data-plan="pro">Subscribe — $29/mo</button>
<script>
document.getElementById('buy').addEventListener('click', async () => {
  const r = await fetch('/api/stripe/checkout', {
    method:  'POST',
    headers: { 'content-type': 'application/json' },
    body:    JSON.stringify({ plan: 'pro' }),
  })
  const { url } = await r.json()
  location.href = url
})
</script>
```

Click → Stripe checkout opens (it's their hosted page, you don't ship the
form) → user pays → Stripe redirects to your `success_url`.

What happens at `success_url` is what chapter 6 covers — that's where you
issue the API key.

## Test it end to end

In Test mode, use card `4242 4242 4242 4242`, any future expiry, any CVC.
Click pay. You'll land on your `success_url?session_id=cs_test_…`.

If you didn't yet build the claim endpoint, you'll get a 404 — that's
expected, fix it next chapter.

Continue with [`06-stripe-webhook-key-issuance.md`](./06-stripe-webhook-key-issuance.md).
