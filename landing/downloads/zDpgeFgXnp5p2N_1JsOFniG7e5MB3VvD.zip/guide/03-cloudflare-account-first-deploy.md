# 3. Cloudflare account setup + first deploy (5 min)

## Sign up

[dash.cloudflare.com/sign-up](https://dash.cloudflare.com/sign-up) — free,
no credit card required, takes ~60 seconds.

After signup, you land on the dashboard. Two things to note:

- Your **account ID** lives in the right sidebar (32-char hex). You'll need
  it for `wrangler.toml` and any API calls.
- The **Workers & Pages** section in the left nav is where everything
  you build today lives.

## Install wrangler

```bash
npm install -g wrangler
wrangler login
```

`wrangler login` opens your browser, you click "Authorize Wrangler". Done.
Wrangler is the CLI that deploys + manages your Worker.

## First deploy

From the repo root:

```bash
cd examples/cf-workers-mcp
npm install
wrangler deploy
```

You'll see something like:

```
   ⛅️ wrangler 3.90.0
   Total Upload: 8.43 KiB / gzip: 3.12 KiB
   Uploaded cf-workers-mcp-sample (1.42 sec)
   Deployed cf-workers-mcp-sample triggers (0.18 sec)
     https://cf-workers-mcp-sample.<your-subdomain>.workers.dev
   Current Version ID: …
```

That URL is **live, on the public internet, with TLS, behind Cloudflare's
edge network, in 200+ cities, in under 2 seconds.**

Test it:

```bash
curl https://cf-workers-mcp-sample.<your-subdomain>.workers.dev/api/echo?msg=hi
{
  "msg": "hi",
  "your_ip": "...",
  "served_by": "cf-workers-mcp-sample"
}
```

## Custom domain (optional, recommended)

Skip this if you don't have a domain yet. With one:

1. Add the domain to Cloudflare (Add Site → enter domain → free tier).
2. Update your registrar's nameservers to the two Cloudflare gives you.
3. Wait ~5-30 minutes for propagation.
4. In Workers & Pages → your worker → Triggers → Custom Domain → add
   `your-mcp.example.com`.

Cloudflare auto-provisions the TLS cert. No certbot, no renew jobs.

## Local dev

```bash
wrangler dev
```

Spawns a local Worker on http://localhost:8787 with the same runtime as
production. Code changes hot-reload. KV operations get persisted to a local
SQLite DB so you don't share state with prod.

## What you just shipped vs what's missing

You now have a public HTTPS endpoint that:
- ✅ runs in Cloudflare's edge runtime
- ✅ handles HTTP, JSON, CORS
- ✅ has 100k free requests/day
- ❌ has no persistence (no API keys, no quotas)
- ❌ has no authentication
- ❌ takes no money

The next two chapters fix the first two of those. Chapter 5 wires Stripe.

Continue with [`04-kv-and-rate-limiting.md`](./04-kv-and-rate-limiting.md).
