# 4. KV namespace + per-IP rate limiting (5 min)

KV is Cloudflare's key-value store. Eventually consistent, globally distributed,
free up to 100k reads/day + 1k writes/day. Perfect for our use case: looking up
"is this API key valid" and "how many free calls did this IP make today".

## Create the namespace

```bash
cd examples/cf-workers-mcp
wrangler kv namespace create MCP_KV
```

Returns:

```
   🌀 Creating namespace with title "cf-workers-mcp-sample-MCP_KV"
   ✨ Success!
   Add the following to your configuration file:
   [[kv_namespaces]]
   binding = "MCP_KV"
   id = "abc123def456…"
```

Paste the `id` into the `[[kv_namespaces]]` section of `wrangler.toml`. Repeat
the command with `--preview` to get a separate ID for `wrangler dev`:

```bash
wrangler kv namespace create MCP_KV --preview
```

Paste the returned `preview_id` into the same section. Now `wrangler dev` and
`wrangler deploy` both have isolated KV.

## How the rate limiter works

The pattern is:

```typescript
const ip   = request.headers.get('cf-connecting-ip') || 'unknown'
const dkey = `free:${ip}:${new Date().toISOString().slice(0, 10)}`
//             ↑ namespace
//                    ↑ identifier
//                              ↑ partition by date so old keys auto-expire

const used = parseInt((await env.MCP_KV.get(dkey)) || '0', 10)
if (used >= LIMIT) return json({ error: 'free tier exhausted' }, { status: 429 })
await env.MCP_KV.put(dkey, String(used + 1), { expirationTtl: 90000 })
//                                              ↑ 25 hours; KV evicts after
```

Three things to know:

1. **Atomicity** — KV doesn't support atomic increments. Two concurrent
   requests can both read `used=4`, both write `5`, and you've under-counted
   by one. At 5/day per IP, this is fine. At 5/sec it isn't — for that you
   need Durable Objects (covered briefly in chapter 9).

2. **Eventual consistency** — a `put` from one edge can take ~60s to be
   visible at another. Don't use KV for "did the user just pay yet" — use
   the Stripe webhook (chapter 6) directly.

3. **TTL is in seconds** — `expirationTtl: 90000` ≈ 25 hours, which means
   yesterday's `free:IP:DATE` key auto-expires before tomorrow uses it.

## What good IP limits look like

```
   plan      what they get                 daily IP cap (anonymous)
   ────────  ────────────────────────────  ────────────────────────
   Free      no API key, just hit the URL   5-10 requests/day per IP
   Pro $29   API key, monthly cap            10,000 requests/month
   Team $99  API key, monthly cap            100,000 requests/month
```

The 5-10/day for anonymous is the load-bearing piece. It says: "you can try
the service free, you can build a demo, but if your project gets serious you
have to pay." Most users hit the cap once and either upgrade or accept they
have to wait until tomorrow.

Don't go below 3/day or you frustrate honest tire-kickers. Don't go above 20
or you'll get scraped by people building wrappers around your free tier.

## What about IPv6?

Cloudflare gives every request an IP via `cf-connecting-ip`. For IPv6,
residential ISPs hand out /64 prefixes — the user's host bits change every
few hours. Per-IPv6-address counting under-counts.

The fix is to compute the /64 prefix and use that as the rate-limit key:

```typescript
function ipKey(ip: string): string {
  if (!ip.includes(':')) return ip                  // IPv4 — use as-is
  // IPv6 — use the /64 prefix (first 4 hex groups)
  const parts = ip.split('::')
  if (parts.length > 2) return ip
  const head = parts[0] ? parts[0].split(':') : []
  const tail = parts[1] ? parts[1].split(':') : []
  const fill = 8 - head.length - tail.length
  if (fill < 0) return ip
  const groups = [...head, ...Array(fill).fill('0'), ...tail]
  return groups.slice(0, 4).map(g => g.padStart(4, '0').toLowerCase()).join(':')
}
```

The full version of this is in `examples/cf-workers-mcp-full/src/_ip.ts`
(buyers' bundle). It handles malformed input + uppercase + compressed
forms.

## Smoke test

```bash
# Fresh IP, fresh day → should succeed N times then 429
for i in {1..12}; do
  curl -s -o /dev/null -w "%{http_code}\n" \
    -X POST https://your-worker.workers.dev/api/protected \
    -H "content-type: application/json" -d '{"msg":"hi"}'
done
# Expected: 200 200 200 200 200 200 200 200 200 200 429 429
```

(default in the sample is 10/day per IP; tweak in `wrangler.toml` →
`FREE_TIER_DAILY_PER_IP`.)

You now have a working free tier. Next we add Stripe so people can buy past it.

Continue with [`05-stripe-pro-tier.md`](./05-stripe-pro-tier.md).
