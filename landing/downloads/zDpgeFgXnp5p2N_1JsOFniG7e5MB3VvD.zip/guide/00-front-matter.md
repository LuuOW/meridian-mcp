# Build Your Own MCP Server With Auth + Billing — In 30 Minutes

**A no-fluff walkthrough of shipping a production MCP server on Cloudflare's
free tier.** Every code sample below is real, tested, and runs as-is. The
finished server can take real money via Stripe and serve thousands of free-tier
users without your bill leaving the noise floor.

By Lucas Kempe · Author of [ask-meridian.uk](https://ask-meridian.uk) (live MCP
server in the official MCP Registry, Pro tier $29/mo, ~3 KB stdio shim).

Version 1.0 · 60+ pages · Code under MIT · Guide for personal + commercial use.
**No reselling the PDF.** No re-publishing as a course or blog post.

---

## Who this is for

You already shipped a `Hello, world` MCP server with `npx create-mcp`. You
realized:

- You can't actually charge for it
- Anyone can drain your LLM bill in an afternoon
- Self-hosting it on Render/Fly is overkill and slow
- The MCP Registry won't accept a localhost URL

This guide walks you from "demo MCP" to "MCP server billed via Stripe, served
from Cloudflare's free tier, listed on the official MCP Registry, with proper
auth and per-user quotas." Total time on the keyboard: ~30 minutes if you
follow it linearly. Total infrastructure cost: $0 until you cross 100k
requests/month.

## Who this is NOT for

- "I want to learn to code" — you should already know JavaScript/TypeScript.
- "I want a one-click SaaS" — this is a guide, you do the typing.
- "I want a different framework" — everything here is Cloudflare Workers +
  Stripe + KV. You can port it later but the stack is opinionated.

## What's in the box

```
   1.  What MCP actually is (the shortest possible explanation)
   2.  The architecture you're going to ship
   3.  Cloudflare account setup + first deploy (5 min)
   4.  KV namespace + per-IP rate limiting (5 min)
   5.  Stripe account + the $29/mo Pro tier (10 min)
   6.  API-key issuance via Stripe webhook (5 min)
   7.  The MCP stdio shim — npm-publishable (5 min)
   8.  Submitting to the official MCP Registry
   9.  Production gotchas (cold starts, KV propagation, webhook retries)
   10. Adding LLM calls (Anthropic, OpenAI, Workers AI, Groq) cost-safely
   11. Bonus: SSE streaming for live progress events
   12. Bonus: Vectorize-backed result caching
```

Every chapter has working code in `examples/`. The `cf-workers-mcp/` example
in the repo is the public sample (free); the `cf-workers-mcp-full/` version
shipped to buyers has the complete Stripe wiring + auth flow.

---

Continue with [`01-what-mcp-actually-is.md`](./01-what-mcp-actually-is.md).
