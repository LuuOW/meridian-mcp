# 10. Adding LLM calls cost-safely

You're charging $29/mo. Your real cost-of-goods is the LLM API call you
make on the user's behalf. If a user can run up $50 of LLM cost on their
$29 plan, you lose money. The whole game is keeping COGS < revenue per user.

## Provider economics (May 2026)

Rough per-call costs for a typical "RAG-shaped" 2k-token in / 1k-token out
generation:

```
   Provider               Model                          per-call cost
   ────────────────────   ────────────────────────────   ─────────────
   Anthropic              claude-sonnet-4-6              $0.012
   Anthropic              claude-haiku-4-5               $0.0008
   OpenAI                 gpt-4o                         $0.018
   OpenAI                 gpt-4o-mini                    $0.0009
   Groq                   llama-3.3-70b-versatile        $0.0005
   Cloudflare Workers AI  @cf/meta/llama-3.3-70b-…       $0.001 (after free tier)
   Cloudflare Workers AI  @cf/meta/llama-3.3-70b-…       FREE (within free tier)
```

The cheapest path is usually **Workers AI for the bulk + Groq for
"needs to be fast" + Anthropic only for the hardest tasks**. If you
build a router that picks the cheapest provider that meets the quality
bar, you can keep COGS under $0.005/call.

At Pro tier (10k calls/month), that's $50 COGS on $29 revenue — still
underwater. Need to either:

1. Lower the per-call cost (cache, downgrade to Haiku/Llama for easy
   tasks)
2. Lower the monthly cap (5k calls/month, raise the tier price)
3. Offer "bring your own key" tier (you charge $9/mo for the routing,
   user pays their own LLM bill)

Most successful MCP services in 2026 use option 3: a small flat fee for
the infrastructure + the user provides their LLM API key.

## Cache aggressively

Same task → same response, 99% of the time. KV-cache the LLM output keyed
by the SHA-256 of the input + parameters:

```typescript
const cacheKey = await sha256(`${task.toLowerCase().trim()}::${limit}::${context}`)
const cached   = await env.MCP_KV.get(`route:${cacheKey}`, 'json')
if (cached) return json({ ...cached, cache_hit: true })

const result = await callLLM(...)
await env.MCP_KV.put(`route:${cacheKey}`, JSON.stringify(result), { expirationTtl: 86400 })
return json(result)
```

24-hour TTL is a good default. Most repeat queries hit within minutes.

## Use Cloudflare AI Gateway

[developers.cloudflare.com/ai-gateway](https://developers.cloudflare.com/ai-gateway)
is a free observability + caching layer that sits in front of any LLM
provider. Set `cache_ttl=86400` and identical upstream requests dedupe at
the gateway, even when your KV cache misses.

Setup:

1. Dashboard → AI → AI Gateway → "+ Create Gateway"
2. Name it (e.g. `my-mcp`)
3. Set `cache_ttl: 86400`, `collect_logs: true`
4. Replace your LLM provider URLs with the gateway-prefixed version:

   ```
   - https://api.groq.com/openai/v1/chat/completions
   + https://gateway.ai.cloudflare.com/v1/{ACCOUNT_ID}/{GATEWAY_NAME}/groq/chat/completions
   ```

5. The dashboard now shows every LLM call — cost, latency, status. Free.

## Pre-validate to avoid wasted calls

Cheap input validation BEFORE the LLM call:

- Reject empty/too-long inputs (`task.length > 800`)
- Reject obvious-spam patterns
- Apply per-key per-day token budgets

A user who'd otherwise consume 1M tokens in an afternoon by accident gets
a 429 at 200k. They contact you, you raise their cap manually if they
have a real use case.

## Streaming where possible

User patience is shorter when nothing visibly happens. Stream LLM tokens
back via SSE so they see "the model is writing":

```typescript
const stream = await fetch(`${API_BASE}/chat/completions`, {
  body: JSON.stringify({ ..., stream: true }),
})
return new Response(stream.body, { headers: { 'content-type': 'text/event-stream' }})
```

Doesn't reduce cost but reduces churn. People wait 20s for streamed
output where they'd abort at 8s of nothing.

## Separate "demo" and "real" pricing

Some users will plug your shim into a CI loop that fires 10k calls/day
"because it's just $29/mo". Defeat this by tiering on intent:

```
   Free        5/day per IP                   demo only
   Pro $29     10k/month + soft 100/hour cap  individual dev
   Team $149   100k/month                     small team
   Enterprise  custom                         talk to me
```

The hourly cap on Pro stops the CI-loop abuse without inconveniencing real
human users.

Continue with [`11-bonus-sse-streaming.md`](./11-bonus-sse-streaming.md).
