# 1. What MCP actually is (the shortest possible explanation)

MCP is a JSON-RPC over stdio (or HTTP) protocol that lets a client like
Claude Code, Cursor, Windsurf, or Cline call **tools** on a server you
control. That's it.

A tool is a function with:
- a name
- a JSON-Schema input
- a string output

The client lists tools (`tools/list`), the user (or the agent) decides one
should fire, the client invokes it (`tools/call`), the server runs it and
returns text. Everything else — auth, billing, observability, your business
logic — is your problem.

## Why two transports

| Transport | When to use | What this guide ships |
|---|---|---|
| **stdio** | A small wrapper that runs on the user's laptop and talks to your real backend over HTTPS. Most MCP clients prefer this — no CORS, no auth headaches, no certs. | ✅ Yes, as the **shim** |
| **HTTP / SSE** | A streamed bidirectional channel. Some clients support it, many don't yet. Higher friction. | ❌ Not in v1.0 (covered briefly in chapter 11) |

The pattern that works in 2026 is **fat backend + thin shim**:

```
   Claude Code
        │ stdio JSON-RPC
        ▼
   ┌──────────────────────────┐
   │ npm-installable shim     │   ~5 KB JavaScript, runs on user laptop
   │ (e.g. byo-mcp-foo-shim)   │   forwards every tools/call over HTTPS
   └────────────┬─────────────┘
                │ HTTPS POST
                ▼
   ┌──────────────────────────┐
   │ your Cloudflare Worker   │   real auth, real billing, real LLM calls
   │ (or Pages Function)      │
   └──────────────────────────┘
```

Why split? Three reasons:

1. **The user installs once.** The shim is ~5 KB; updating it is a `npm
   update` they never do. Your real code lives on the server, redeploys
   instantly without anyone restarting their laptop.
2. **Secrets stay on the server.** API keys for upstream LLMs (Anthropic,
   Groq, etc.) never touch the user's disk.
3. **Centralized observability.** Every call goes through your Worker.
   You see usage. You can rate-limit. You can ship a feature flag.

This guide ships both halves. The shim is a single `shim.mjs` file. The
Worker is a `src/index.ts` file. Both deploy with one command.

---

Continue with [`02-the-architecture.md`](./02-the-architecture.md).
