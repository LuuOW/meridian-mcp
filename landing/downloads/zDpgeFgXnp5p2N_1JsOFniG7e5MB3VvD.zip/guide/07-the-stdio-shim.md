# 7. The MCP stdio shim — npm-publishable (5 min)

The shim is what users install. Goals:

- ≤ 5 KB of JavaScript, zero dependencies (so it's `npx`-friendly)
- Speak MCP JSON-RPC on stdin/stdout
- Forward every `tools/call` to your HTTPS backend with the user's bearer key
- Surface upstream errors in a way Claude Code can render

## Minimal shim

Already shipped under `examples/stdio-shim/shim.mjs`. The bones:

```javascript
#!/usr/bin/env node
import readline from 'node:readline'

const API_URL = process.env.BYO_MCP_API_URL || 'http://localhost:8787'
const API_KEY = process.env.BYO_MCP_API_KEY || ''

const TOOLS = [{
  name: 'echo',
  description: 'Echo a message back. Demo tool — replace with your own.',
  inputSchema: {
    type:       'object',
    properties: { msg: { type: 'string' } },
    required:   ['msg'],
  },
}]

const rl  = readline.createInterface({ input: process.stdin })
const out = (obj) => process.stdout.write(JSON.stringify(obj) + '\n')

rl.on('line', async (line) => {
  let req
  try { req = JSON.parse(line) } catch { return }

  if (req.method === 'initialize') {
    return out({ jsonrpc: '2.0', id: req.id, result: {
      protocolVersion: '2025-06-18',
      capabilities:    { tools: {} },
      serverInfo:      { name: 'byo-mcp-shim', version: '0.1.0' },
    }})
  }

  if (req.method === 'tools/list') {
    return out({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS } })
  }

  if (req.method === 'tools/call' && req.params?.name === 'echo') {
    const headers = { 'content-type': 'application/json' }
    if (API_KEY) headers.authorization = `Bearer ${API_KEY}`
    const r    = await fetch(`${API_URL}/api/protected`, {
      method: 'POST', headers,
      body:   JSON.stringify(req.params.arguments),
    })
    const data = await r.json()
    if (!r.ok) return out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: data.error }})
    return out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(data) }]}})
  }
})
```

## How users install

Once you publish to npm, users add this to their MCP client config:

```json
// Claude Code: ~/.claude/claude_desktop_config.json
{
  "mcpServers": {
    "your-server-name": {
      "command": "npx",
      "args":    ["-y", "byo-mcp-foo-shim"],
      "env":     {
        "BYO_MCP_API_URL": "https://your-mcp.example.com",
        "BYO_MCP_API_KEY": "mrd_live_…"
      }
    }
  }
}
```

`npx -y` ensures the shim is fetched from npm if not already cached. The
`-y` skips the install prompt — important for first-run UX.

For Cursor: `~/.cursor/mcp.json`, same shape. For Cline: settings → MCP.

## Publishing to npm

```bash
cd examples/stdio-shim
npm login
npm publish --access public
```

If your name has a scope (`@yourname/foo`), `--access public` is required
for free accounts. Otherwise it's not.

Bump the version on every change:

```bash
npm version patch  # 0.1.0 → 0.1.1
npm publish
```

Once published, your users do `npx -y your-package-name` and the shim is
fetched + cached on first run.

## Make multiple tools work

The simplest pattern: a static array of `TOOLS`, each with its own handler.

```javascript
const TOOLS = [
  { name: 'echo',   description: '...', inputSchema: {...} },
  { name: 'search', description: '...', inputSchema: {...} },
  { name: 'render', description: '...', inputSchema: {...} },
]

const handlers = {
  echo:   async (args) => callBackend('/api/echo', args),
  search: async (args) => callBackend('/api/search', args),
  render: async (args) => callBackend('/api/render', args),
}

if (req.method === 'tools/call') {
  const handler = handlers[req.params.name]
  if (!handler) return out({ jsonrpc: '2.0', id: req.id, error: { code: -32601, message: 'unknown tool' }})
  try {
    const data = await handler(req.params.arguments)
    return out({ jsonrpc: '2.0', id: req.id, result: { content: [{ type: 'text', text: JSON.stringify(data) }]}})
  } catch (e) {
    return out({ jsonrpc: '2.0', id: req.id, error: { code: -32000, message: e.message }})
  }
}
```

## Better: dynamic tool list

If your service evolves, you don't want users to `npm update` every time.
Have the shim fetch the tool list from your backend:

```javascript
let TOOLS = []
async function refreshTools() {
  const r = await fetch(`${API_URL}/api/tools`, { headers: API_KEY ? { authorization: `Bearer ${API_KEY}` } : {} })
  if (r.ok) TOOLS = await r.json()
}

// Refresh on init
if (req.method === 'initialize') {
  await refreshTools()
  return out({ /* ... */ })
}
```

Now you ship a new tool just by updating the backend — no shim release.

## Backwards compatibility

When you change a tool's input schema, **don't break existing users**. Pin
versions:

```javascript
const TOOLS = [
  { name: 'echo',   inputSchema: {...} },          // v1
  { name: 'echo_v2', inputSchema: {...} },         // v2 with new fields
]
```

Or use `additionalProperties: true` in the schema so old shims keep working
when you add new fields.

Continue with [`08-mcp-registry-submission.md`](./08-mcp-registry-submission.md).
